import os
from datetime import datetime

from werkzeug.security import generate_password_hash

from database import DB_PATH, get_connection, init_db


# Contraseña única para TODOS los usuarios de demostración.
# No se escribe ninguna contraseña real en el código: se toma de SEED_PASSWORD.
SEED_PASSWORD = os.environ.get("SEED_PASSWORD", "").strip()

USERS = [
    ("admin@piloto.cl", "Administrador piloto", "admin"),
    ("evaluador1@piloto.cl", "Evaluador 1", "evaluador"),
    ("evaluador2@piloto.cl", "Evaluador 2", "evaluador"),
    ("director@piloto.cl", "Director Departamento", "evaluador"),
]


ACADEMICOS = [
    {
        "codigo": "A-001",
        "jerarquia": "Asociado",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2007,
        "areas": [
            ("Docencia", 16.5, 119, 43.0, [
                ("Corrección de pruebas", "Metodología de la Investigación y Escritura Científica", "0 / 3", "0 / 0", "", "Declarativa"),
                ("Guías de memorias de título", "", "4 / 0", "4 / 0", "2 tesistas de pregrado", "Declarativa"),
                ("Docencia directa frente alumnos", "Electivo de Especialización", "0 / 0", "4 / 0", "Mecánica no-lineal de materiales", "Declarativa"),
            ]),
            ("Investigación y Desarrollo", 20, 30, 45.2, [
                ("Ejecución de Proyectos ANID", "", "14 / 0", "14 / 0", "Fondecyt Regular y Fondef IDeA I+D", "Declarativa"),
                ("Artículo en revista", "", "6 / 0", "6 / 0", "Un artículo científico por semestre", "Declarativa"),
            ]),
            ("Asistencia Técnica", 0, 15, 0.9, [("Asesorías profesionales", "", "0 / 15", "0 / 0", "Par evaluador CNA", "Declarativa")]),
            ("Administración Académica", 0, 44, 2.7, [("Consejero/a - Consejo Departamental", "", "0 / 10", "0 / 10", "", "Declarativa")]),
            ("Extensión - VIME", 3, 30, 8.3, [("Participación en conferencias", "", "0 / 0", "6 / 30", "Congresos de mecánica computacional", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-002",
        "jerarquia": "Asistente",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2008,
        "areas": [
            ("Docencia", 15.5, 318, 40.1, [
                ("Docencia directa frente alumnos", "Mecánica de Suelos I", "4 / 0", "4 / 0", "", "Declarativa"),
                ("Docencia laboratorio directo", "Mecánica de Suelos I / II", "8 / 0", "8 / 0", "Laboratorio", "Declarativa"),
                ("Corrección y evaluación trabajos de titulación", "", "0 / 40", "0 / 40", "", "Declarativa"),
            ]),
            ("Asistencia Técnica", 1, 0, 2.6, [("Ejecución de Servicios de A.T.", "", "1 / 0", "1 / 0", "Proyecto EA, ensayos de aptitud", "Declarativa")]),
            ("Administración Académica", 20.5, 0, 53.0, [
                ("Subdirector/a Departamento", "", "11 / 0", "11 / 0", "Subdirector Docente", "Declarativa"),
                ("Jefe/a de Laboratorio", "", "5 / 0", "5 / 0", "Laboratorio de Materiales y Geotecnia", "Declarativa"),
            ]),
            ("Extensión - VIME", 1.5, 0, 3.9, [("Ejecución de Proyectos VIME", "", "1.5 / 0", "1.5 / 0", "Proyecto STEM y mentorías tempranas", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-003",
        "jerarquia": "Asociado",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2007,
        "areas": [
            ("Docencia", 15.5, 110, 35.6, [("Docencia directa frente alumnos", "Mecánica de Sólidos / Mecánica No Lineal", "6 / 0", "12 / 0", "", "Declarativa")]),
            ("Investigación y Desarrollo", 26, 0, 59.8, [("Ejecución de Proyectos ANID", "", "23 / 0", "23 / 0", "Fondecyt, Anillo Tecnológico y co-investigación", "Declarativa")]),
            ("Administración Académica", 6, 32, 13.8, [("Director/a Magíster", "", "2 / 0", "2 / 0", "", "Declarativa")]),
            ("Extensión - VIME", 0, 60, 13.4, [("Participación en conferencias", "", "0 / 40", "0 / 16", "WCCM 2026 y conferencia chilena", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-004",
        "jerarquia": "Asistente",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2011,
        "areas": [
            ("Docencia", 29, 600, 66.7, [("Docencia directa frente alumnos", "Hidráulica / Seminario Ingeniería I", "10 / 0", "10 / 0", "", "Declarativa")]),
            ("Investigación y Desarrollo", 0, 90, 10.3, [("Artículo en congreso nacional", "", "0 / 30", "0 / 30", "", "Declarativa")]),
            ("Administración Académica", 1, 30, 3.4, [("Consejero/a - Consejo Departamental", "", "1 / 0", "1 / 0", "", "Declarativa")]),
            ("Extensión - VIME", 0, 112, 12.9, [("Participación en conferencias", "", "0 / 40", "0 / 40", "", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-005",
        "jerarquia": "Asociado",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2007,
        "areas": [
            ("Docencia", 26, 12, 63.2, [("Docencia directa frente alumnos", "Tratamiento de Agua Potable / Gestión Ambiental", "8 / 0", "4 / 0", "", "Declarativa")]),
            ("Investigación y Desarrollo", 0, 500, 14.8, [("Artículo en congreso internacional", "", "0 / 250", "0 / 250", "Escribir 2 artículos para revista", "Declarativa")]),
            ("Asistencia Técnica", 8, 0, 19.5, [("Ejecución de Servicios de A.T.", "", "8 / 0", "8 / 0", "Proyecto DOH en la Araucanía", "Declarativa")]),
            ("Administración Académica", 2, 0, 4.9, [("Consejero/a - Consejo Departamental", "", "2 / 0", "2 / 0", "", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-006",
        "jerarquia": "Asistente",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2015,
        "areas": [
            ("Docencia", 27, 32, 61.8, [("Docencia directa frente alumnos", "Tecnología del Hormigón", "4 / 0", "4 / 0", "", "Declarativa")]),
            ("Investigación y Desarrollo", 24.5, 0, 56.1, [("Ejecución de Proyectos ANID", "", "15 / 0", "15 / 0", "FONDEF ID25I10465", "Declarativa")]),
            ("Extensión - VIME", 1, 0, 2.3, [("Representaciones externas", "", "1 / 0", "1 / 0", "Participación centro del hormigón", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-007",
        "jerarquia": "Asociado",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2009,
        "areas": [
            ("Docencia", 10.5, 50, 25.1, [("Docencia directa frente alumnos", "Ciencias Ambientales / Electivo A", "6 / 0", "9 / 0", "Incluye asignatura vespertina", "Declarativa")]),
            ("Investigación y Desarrollo", 36, 0, 86.0, [("Artículo en revista", "", "8 / 0", "8 / 0", "", "Declarativa")]),
            ("Asistencia Técnica", 2, 0, 4.8, [("Asesorías Profesionales", "", "2 / 0", "2 / 0", "Convenios DOH, INDAP", "Declarativa")]),
            ("Extensión - VIME", 1, 0, 2.4, [("Otras actividades", "", "1 / 0", "1 / 0", "Laboratorio Ambientales y Sostenibilidad USACH", "Declarativa")]),
            ("Educación Continua - VIME", 0, 12, 0.7, [("Otras actividades", "", "0 / 0", "0 / 12", "Diplomado en Recursos Hídricos", "Declarativa")]),
        ],
    },
    {
        "codigo": "A-008",
        "jerarquia": "Asociado",
        "jornada": "Jornada Completa",
        "anio_ingreso": 2007,
        "areas": [
            ("Docencia", 18.5, 269, 42.7, [("Docencia directa frente alumnos", "", "6 / 0", "6 / 0", "", "Declarativa")]),
            ("Investigación y Desarrollo", 16, 80, 36.9, [("Ejecución de Proyectos ANID", "", "8 / 0", "8 / 0", "", "Declarativa")]),
            ("Asistencia Técnica", 0, 70, 4.0, [("Formulación de Servicios de A.T.", "", "0 / 10", "0 / 10", "", "Declarativa")]),
            ("Perfeccionamiento", 0, 30, 1.7, [("Otras actividades", "", "0 / 15", "0 / 15", "", "Declarativa")]),
            ("Administración Académica", 5, 5, 11.7, [("Jefe/a de Carrera", "", "2 / 0", "2 / 0", "", "Declarativa")]),
            ("Extensión - VIME", 0, 10, 0.6, [("Organización y participación en conferencias", "", "0 / 5", "0 / 5", "", "Declarativa")]),
            ("Educación Continua - VIME", 0, 20, 1.2, [("Otras actividades", "", "0 / 10", "0 / 10", "", "Declarativa")]),
        ],
    },
]


def _parse_pair(value):
    """Parsea valores del tipo '4 / 0' como (horas_semanales, horas_anuales)."""
    try:
        left, right = str(value or "0 / 0").split("/", 1)
        return float(left.strip().replace(",", ".")), float(right.strip().replace(",", "."))
    except Exception:
        return 0.0, 0.0


def _fmt_num(value):
    value = round(float(value), 2)
    if abs(value - int(value)) < 0.01:
        return str(int(value))
    return f"{value:.2f}".rstrip("0").rstrip(".")


def add_reconciliation_activities(db):
    """
    Agrega filas de cuadratura cuando el total declarado del área es mayor que
    el detalle de actividades visible en el piloto.

    Criterio usado:
    - horas_semana se interpreta como promedio semanal anual del área;
    - por eso se compara contra el promedio de horas semanales visibles entre
      primer y segundo semestre;
    - horas_anio se compara contra la suma anual visible en ambos semestres.

    La fila no inventa una actividad sustantiva. Solo explicita que hay horas
    del CDA que estaban en el resumen del área, pero no estaban desagregadas
    en la tabla de actividades del prototipo.
    """
    areas = db.execute(
        """
        SELECT a.codigo, ac.id, ac.nombre, ac.horas_semana, ac.horas_anio
        FROM academicos a
        JOIN areas_compromiso ac ON ac.academico_id = a.id
        ORDER BY a.codigo, ac.id
        """
    ).fetchall()
    for area in areas:
        actividades = db.execute(
            """
            SELECT primer_semestre, segundo_semestre
            FROM actividades_comprometidas
            WHERE area_id = ?
            """,
            (area["id"],),
        ).fetchall()
        sem1 = sem2 = anual = 0.0
        for act in actividades:
            s1, a1 = _parse_pair(act["primer_semestre"])
            s2, a2 = _parse_pair(act["segundo_semestre"])
            sem1 += s1
            sem2 += s2
            anual += a1 + a2

        visible_promedio = (sem1 + sem2) / 2
        falta_sem_promedio = max(0.0, float(area["horas_semana"] or 0) - visible_promedio)
        falta_anual_total = max(0.0, float(area["horas_anio"] or 0) - anual)

        if falta_sem_promedio > 0.01 or falta_anual_total > 0.01:
            primer = f"{_fmt_num(falta_sem_promedio)} / {_fmt_num(falta_anual_total / 2)}"
            segundo = f"{_fmt_num(falta_sem_promedio)} / {_fmt_num(falta_anual_total / 2)}"
            db.execute(
                """
                INSERT INTO actividades_comprometidas
                (area_id, actividad, contexto, primer_semestre, segundo_semestre, observacion, evidencia)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    area["id"],
                    "Horas declaradas en CDA no desagregadas en actividades específicas",
                    "Cuadratura del compromiso",
                    primer,
                    segundo,
                    "Fila agregada para que el detalle de actividades cuadre con el resumen superior del área. No representa una actividad adicional.",
                    "Declarativa",
                ),
            )


def seed():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()
    now = datetime.now().isoformat(timespec="seconds")
    with get_connection() as db:
        db.executescript(
            """
            DELETE FROM bitacora;
            DELETE FROM evaluacion_final_comision;
            DELETE FROM evaluaciones_individuales;
            DELETE FROM asignaciones_evaluacion;
            DELETE FROM actividades_comprometidas;
            DELETE FROM areas_compromiso;
            DELETE FROM academicos;
            DELETE FROM usuarios;
            DELETE FROM sqlite_sequence;
            """
        )

        user_ids = {}
        for email, nombre, rol in USERS:
            cur = db.execute(
                """
                INSERT INTO usuarios (email, nombre, password_hash, rol, creado_en)
                VALUES (?, ?, ?, ?, ?)
                """,
                (email, nombre, generate_password_hash(SEED_PASSWORD), rol, now),
            )
            user_ids[email] = cur.lastrowid

        academico_ids = {}
        for item in ACADEMICOS:
            cur = db.execute(
                """
                INSERT INTO academicos (codigo, jerarquia, jornada, departamento, periodo, anio_ingreso, creado_en)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    item["codigo"],
                    item["jerarquia"],
                    item["jornada"],
                    "Departamento de Ingeniería en Obras Civiles",
                    "2026",
                    item["anio_ingreso"],
                    now,
                ),
            )
            academico_id = cur.lastrowid
            academico_ids[item["codigo"]] = academico_id

            for nombre, semana, anio, peso, actividades in item["areas"]:
                area_cur = db.execute(
                    """
                    INSERT INTO areas_compromiso
                    (academico_id, nombre, horas_semana, horas_anio, peso, estado)
                    VALUES (?, ?, ?, ?, ?, 'Pendiente')
                    """,
                    (academico_id, nombre, semana, anio, peso),
                )
                area_id = area_cur.lastrowid
                for actividad in actividades:
                    db.execute(
                        """
                        INSERT INTO actividades_comprometidas
                        (area_id, actividad, contexto, primer_semestre, segundo_semestre, observacion, evidencia)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (area_id, *actividad),
                    )

        evaluadores = [
            user_ids["evaluador1@piloto.cl"],
            user_ids["evaluador2@piloto.cl"],
            user_ids["director@piloto.cl"],
        ]
        for academico_id in academico_ids.values():
            for evaluador_id in evaluadores:
                db.execute(
                    """
                    INSERT INTO asignaciones_evaluacion
                    (academico_id, evaluador_id, estado, creado_en)
                    VALUES (?, ?, 'pendiente', ?)
                    """,
                    (academico_id, evaluador_id, now),
                )

        add_reconciliation_activities(db)

        db.execute(
            """
            INSERT INTO bitacora (usuario_id, accion, entidad, detalle, creado_en)
            VALUES (NULL, 'seed', 'sistema', 'Base de datos inicializada con datos del mock-up', ?)
            """,
            (now,),
        )
        db.commit()


def main():
    """seed.py es DESTRUCTIVO: borra la base y la recrea con datos de demostración.

    Por eso nunca se ejecuta en el arranque de la aplicación y exige confirmación
    explícita. Nunca debe correrse contra la base del piloto en Render.
    """
    if os.environ.get("FLASK_ENV", "").lower() == "production":
        raise SystemExit(
            "Bloqueado: FLASK_ENV=production. seed.py destruye la base de datos y "
            "no debe ejecutarse en el entorno del piloto oficial."
        )

    if not SEED_PASSWORD:
        raise SystemExit(
            "Defina SEED_PASSWORD antes de ejecutar seed.py.\n"
            "Ejemplo:  SEED_PASSWORD='clave-local-demo' python seed.py"
        )

    if os.path.exists(DB_PATH):
        print(f"Se ELIMINARÁ y recreará la base en: {DB_PATH}")
        if input("Escriba BORRAR para confirmar: ").strip() != "BORRAR":
            raise SystemExit("Cancelado. No se modificó ningún dato.")

    seed()
    print(f"Base de datos de demostración creada en {DB_PATH}")
    print("Usuarios de demostración: admin@piloto.cl, evaluador1@piloto.cl, "
          "evaluador2@piloto.cl, director@piloto.cl")
    print("Todos usan la contraseña indicada en SEED_PASSWORD.")


if __name__ == "__main__":
    main()

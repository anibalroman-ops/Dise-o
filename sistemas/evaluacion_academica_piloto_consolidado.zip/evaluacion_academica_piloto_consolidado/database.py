import os
import sqlite3
from datetime import datetime

from dotenv import load_dotenv
from werkzeug.security import generate_password_hash

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DB_RELPATH = os.path.join('data', 'evaluacion.db')


def resolve_db_path():
    raw = os.environ.get('DATABASE_PATH', '').strip() or DEFAULT_DB_RELPATH
    return raw if os.path.isabs(raw) else os.path.join(BASE_DIR, raw)


def resolve_upload_root():
    configured = os.environ.get('UPLOAD_ROOT', '').strip()
    if configured:
        return configured if os.path.isabs(configured) else os.path.join(BASE_DIR, configured)
    db_path = resolve_db_path()
    # Si la base vive en /var/data/evaluacion.db, las evidencias también deben
    # quedar en el disco persistente de Render.
    if os.path.isabs(db_path) and os.path.dirname(db_path) != BASE_DIR:
        return os.path.join(os.path.dirname(db_path), 'uploads')
    return os.path.join(BASE_DIR, 'data', 'uploads')


DB_PATH = resolve_db_path()
UPLOAD_ROOT = resolve_upload_root()


def get_connection():
    directorio = os.path.dirname(DB_PATH)
    if directorio:
        os.makedirs(directorio, exist_ok=True)
    os.makedirs(UPLOAD_ROOT, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    conn.execute('PRAGMA journal_mode = WAL')
    conn.execute('PRAGMA busy_timeout = 30000')
    return conn


def database_exists():
    return os.path.exists(DB_PATH)


def _columns(db, table):
    return {row['name'] for row in db.execute(f'PRAGMA table_info({table})').fetchall()}


def _add_columns(db, table, specs):
    cols = _columns(db, table)
    for name, ddl in specs.items():
        if name not in cols:
            db.execute(f'ALTER TABLE {table} ADD COLUMN {name} {ddl}')


def init_db():
    with get_connection() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                nombre TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                rol TEXT NOT NULL CHECK (rol IN ('admin','evaluador')),
                activo INTEGER NOT NULL DEFAULT 1,
                creado_en TEXT NOT NULL
            );

            /* Persona real: una sola fila aunque existan varias evaluaciones anuales. */
            CREATE TABLE IF NOT EXISTS personas_academicas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo TEXT NOT NULL UNIQUE,
                nombre TEXT NOT NULL,
                apellido_paterno TEXT,
                apellido_materno TEXT,
                nombres TEXT,
                departamento_base TEXT,
                anio_ingreso INTEGER,
                creado_en TEXT NOT NULL,
                actualizado_en TEXT NOT NULL
            );

            /*
             * Esta tabla conserva el nombre histórico "academicos" para no romper
             * las rutas del piloto, pero cada fila representa ahora UNA EVALUACIÓN
             * ANUAL (por ejemplo A-001-2024). persona_id enlaza a la persona real.
             */
            CREATE TABLE IF NOT EXISTS academicos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo TEXT NOT NULL UNIQUE,
                jerarquia TEXT NOT NULL,
                jornada TEXT NOT NULL,
                departamento TEXT NOT NULL,
                periodo TEXT NOT NULL,
                anio_ingreso INTEGER,
                requisito_art25_cumple INTEGER,
                requisito_art25_observacion TEXT,
                requisito_art25_actualizado_por INTEGER,
                requisito_art25_actualizado_en TEXT,
                creado_en TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS areas_compromiso (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                academico_id INTEGER NOT NULL,
                nombre TEXT NOT NULL,
                horas_semana REAL NOT NULL DEFAULT 0,
                horas_anio REAL NOT NULL DEFAULT 0,
                peso REAL NOT NULL DEFAULT 0,
                estado TEXT NOT NULL DEFAULT 'Pendiente',
                FOREIGN KEY (academico_id) REFERENCES academicos(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS actividades_comprometidas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                area_id INTEGER NOT NULL,
                actividad TEXT NOT NULL,
                contexto TEXT,
                primer_semestre TEXT,
                segundo_semestre TEXT,
                observacion TEXT,
                evidencia TEXT,
                FOREIGN KEY (area_id) REFERENCES areas_compromiso(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS evidencias (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                persona_id INTEGER,
                evaluacion_id INTEGER,
                anio INTEGER,
                area_id INTEGER,
                actividad_id INTEGER,
                titulo TEXT NOT NULL,
                descripcion TEXT,
                nombre_original TEXT NOT NULL,
                nombre_guardado TEXT NOT NULL,
                ruta_relativa TEXT NOT NULL,
                extension TEXT,
                mime_type TEXT,
                tamano INTEGER NOT NULL DEFAULT 0,
                fecha_carga TEXT NOT NULL,
                origen TEXT,
                estado_asociacion TEXT NOT NULL DEFAULT 'pendiente',
                FOREIGN KEY (persona_id) REFERENCES personas_academicas(id) ON DELETE SET NULL,
                FOREIGN KEY (evaluacion_id) REFERENCES academicos(id) ON DELETE CASCADE,
                FOREIGN KEY (area_id) REFERENCES areas_compromiso(id) ON DELETE SET NULL,
                FOREIGN KEY (actividad_id) REFERENCES actividades_comprometidas(id) ON DELETE SET NULL
            );

            CREATE TABLE IF NOT EXISTS importaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER,
                archivo_zip TEXT NOT NULL,
                persona_id INTEGER,
                iniciado_en TEXT NOT NULL,
                finalizado_en TEXT,
                estado TEXT NOT NULL DEFAULT 'procesando',
                reporte_json TEXT,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
                FOREIGN KEY (persona_id) REFERENCES personas_academicas(id) ON DELETE SET NULL
            );

            CREATE TABLE IF NOT EXISTS asignaciones_evaluacion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                academico_id INTEGER NOT NULL,
                evaluador_id INTEGER NOT NULL,
                estado TEXT NOT NULL DEFAULT 'pendiente',
                creado_en TEXT NOT NULL,
                UNIQUE (academico_id, evaluador_id),
                FOREIGN KEY (academico_id) REFERENCES academicos(id) ON DELETE CASCADE,
                FOREIGN KEY (evaluador_id) REFERENCES usuarios(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS evaluaciones_individuales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asignacion_id INTEGER NOT NULL,
                area_id INTEGER NOT NULL,
                nivel INTEGER CHECK (nivel BETWEEN 0 AND 4),
                evidencia_predominante TEXT,
                confianza TEXT,
                fundamento TEXT,
                fortalezas TEXT,
                aspectos_mejorar TEXT,
                recomendacion TEXT,
                estado TEXT NOT NULL DEFAULT 'borrador',
                actualizado_en TEXT NOT NULL,
                enviado_en TEXT,
                UNIQUE (asignacion_id, area_id),
                FOREIGN KEY (asignacion_id) REFERENCES asignaciones_evaluacion(id) ON DELETE CASCADE,
                FOREIGN KEY (area_id) REFERENCES areas_compromiso(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS evaluacion_final_comision (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                area_id INTEGER NOT NULL UNIQUE,
                nivel_final INTEGER NOT NULL CHECK (nivel_final BETWEEN 0 AND 4),
                fundamento_final TEXT NOT NULL,
                fortalezas_final TEXT,
                aspectos_mejorar_final TEXT,
                recomendacion_final TEXT,
                comentario_final TEXT,
                consenso INTEGER NOT NULL DEFAULT 0,
                usuario_id INTEGER NOT NULL,
                actualizado_en TEXT NOT NULL,
                FOREIGN KEY (area_id) REFERENCES areas_compromiso(id) ON DELETE CASCADE,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS bitacora (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER,
                accion TEXT NOT NULL,
                entidad TEXT,
                entidad_id INTEGER,
                detalle TEXT,
                creado_en TEXT NOT NULL,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
            );
            """
        )
        migrate_db(db)
        db.commit()


def migrate_db(db):
    # Metadatos de evaluación anual / persona real.
    _add_columns(db, 'academicos', {
        'anio_ingreso': 'INTEGER',
        'requisito_art25_cumple': 'INTEGER',
        'requisito_art25_observacion': 'TEXT',
        'requisito_art25_actualizado_por': 'INTEGER',
        'requisito_art25_actualizado_en': 'TEXT',
        'persona_id': 'INTEGER REFERENCES personas_academicas(id) ON DELETE SET NULL',
        'codigo_base': 'TEXT',
        'nombre': 'TEXT',
        'anio_evaluacion': 'INTEGER',
        'source_excel': 'TEXT',
        'source_excel_sha256': 'TEXT',
        'importado_en': 'TEXT',
    })

    # Resumen calculado automáticamente. Los tres campos históricos se mantienen:
    # horas_semana = promedio semanal equivalente comprometido,
    # horas_anio = horas comprometidas anualizadas,
    # peso = porcentaje comprometido usado para ponderación de la evaluación.
    _add_columns(db, 'areas_compromiso', {
        'horas_comprometidas_anuales': 'REAL NOT NULL DEFAULT 0',
        'horas_realizadas_anuales': 'REAL NOT NULL DEFAULT 0',
        'promedio_semanal_comprometido': 'REAL NOT NULL DEFAULT 0',
        'promedio_semanal_realizado': 'REAL NOT NULL DEFAULT 0',
        'porcentaje_comprometido': 'REAL NOT NULL DEFAULT 0',
        'porcentaje_realizado': 'REAL NOT NULL DEFAULT 0',
        'resumen_excel_comp_semana': 'REAL NOT NULL DEFAULT 0',
        'resumen_excel_comp_anual': 'REAL NOT NULL DEFAULT 0',
        'resumen_excel_real_semana': 'REAL NOT NULL DEFAULT 0',
        'resumen_excel_real_anual': 'REAL NOT NULL DEFAULT 0',
        'source_row': 'INTEGER',
    })

    # Desagregación real de la planilla por semestre y condición.
    _add_columns(db, 'actividades_comprometidas', {
        's1_comp_hsemana': 'REAL',
        's1_comp_hsemestre': 'REAL',
        's1_real_hsemana': 'REAL',
        's1_real_hsemestre': 'REAL',
        's2_comp_hsemana': 'REAL',
        's2_comp_hsemestre': 'REAL',
        's2_real_hsemana': 'REAL',
        's2_real_hsemestre': 'REAL',
        'anio': 'INTEGER',
        'evidencia_textual': 'TEXT',
        'source_row': 'INTEGER',
        'source_json': 'TEXT',
    })

    final_cols = _columns(db, 'evaluacion_final_comision')
    if 'director_id' in final_cols and 'usuario_id' not in final_cols:
        db.execute('ALTER TABLE evaluacion_final_comision RENAME COLUMN director_id TO usuario_id')
    _add_columns(db, 'evaluacion_final_comision', {
        'fortalezas_final': 'TEXT',
        'aspectos_mejorar_final': 'TEXT',
        'comentario_final': 'TEXT',
    })

    usuario_cols = _columns(db, 'usuarios')
    if 'rol' in usuario_cols:
        db.execute("UPDATE usuarios SET rol = 'evaluador' WHERE rol = 'director'")

    db.executescript(
        """
        CREATE INDEX IF NOT EXISTS idx_academicos_persona_anio ON academicos(persona_id, anio_evaluacion);
        CREATE INDEX IF NOT EXISTS idx_areas_academico ON areas_compromiso(academico_id);
        CREATE INDEX IF NOT EXISTS idx_actividades_area ON actividades_comprometidas(area_id);
        CREATE INDEX IF NOT EXISTS idx_evidencias_eval ON evidencias(evaluacion_id);
        CREATE INDEX IF NOT EXISTS idx_evidencias_area ON evidencias(area_id);
        CREATE INDEX IF NOT EXISTS idx_evidencias_actividad ON evidencias(actividad_id);
        CREATE INDEX IF NOT EXISTS idx_evidencias_persona ON evidencias(persona_id);
        """
    )


def ensure_initial_admin():
    with get_connection() as db:
        total = db.execute('SELECT COUNT(*) AS n FROM usuarios').fetchone()['n']
        if total > 0:
            return False, 'Ya existen usuarios: no se crea administrador inicial.'

        email = os.environ.get('ADMIN_INITIAL_EMAIL', '').strip().lower()
        password = os.environ.get('ADMIN_INITIAL_PASSWORD', '')
        nombre = os.environ.get('ADMIN_INITIAL_NAME', 'Administrador del piloto').strip()

        if not email or not password:
            return False, (
                'Base sin usuarios. Defina ADMIN_INITIAL_EMAIL y ADMIN_INITIAL_PASSWORD '
                'para crear el administrador inicial.'
            )

        db.execute(
            """
            INSERT INTO usuarios (email, nombre, password_hash, rol, activo, creado_en)
            VALUES (?, ?, ?, 'admin', 1, ?)
            """,
            (email, nombre, generate_password_hash(password), datetime.now().isoformat(timespec='seconds')),
        )
        db.execute(
            """
            INSERT INTO bitacora (usuario_id, accion, entidad, detalle, creado_en)
            VALUES (NULL, 'bootstrap', 'usuarios', 'Creación del administrador inicial', ?)
            """,
            (datetime.now().isoformat(timespec='seconds'),),
        )
        db.commit()
        return True, f'Administrador inicial creado: {email}'


def bootstrap_database():
    existia = database_exists()
    init_db()
    creado, mensaje = ensure_initial_admin()
    return {
        'db_path': DB_PATH,
        'upload_root': UPLOAD_ROOT,
        'db_preexistente': existia,
        'admin_creado': creado,
        'mensaje': mensaje,
    }


def log_event(usuario_id, accion, entidad=None, entidad_id=None, detalle=None):
    with get_connection() as db:
        db.execute(
            """
            INSERT INTO bitacora (usuario_id, accion, entidad, entidad_id, detalle, creado_en)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (usuario_id, accion, entidad, entidad_id, detalle, datetime.now().isoformat(timespec='seconds')),
        )
        db.commit()

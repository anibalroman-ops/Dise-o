"""
Crea o actualiza usuarios del piloto desde línea de comandos.

Uso:
  python crear_usuarios_piloto.py

Toma DATABASE_PATH desde .env. Ajusta la lista USUARIOS antes de ejecutar si
quieres usar correos reales de la comisión.
"""
import os
import sqlite3
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash

load_dotenv()

DB_PATH = os.getenv("DATABASE_PATH", "data/evaluacion.db")

USUARIOS = [
    {"email": "evaluador1@piloto.cl", "nombre": "Evaluador 1", "rol": "evaluador", "password": "CambiarClaveEval1123"},
    {"email": "evaluador2@piloto.cl", "nombre": "Evaluador 2", "rol": "evaluador", "password": "CambiarClaveEval2123"},
    {"email": "evaluador3@piloto.cl", "nombre": "Evaluador 3", "rol": "evaluador", "password": "CambiarClaveEval3123"},
    {"email": "director@piloto.cl", "nombre": "Director Departamento", "rol": "evaluador", "password": "CambiarClaveDirector123"},
]

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

for u in USUARIOS:
    cur.execute("SELECT id FROM usuarios WHERE email = ?", (u["email"],))
    row = cur.fetchone()
    if row:
        cur.execute(
            """
            UPDATE usuarios
            SET nombre = ?, rol = ?, password_hash = ?, activo = 1
            WHERE email = ?
            """,
            (u["nombre"], u["rol"], generate_password_hash(u["password"]), u["email"]),
        )
        usuario_id = row["id"]
        print(f"Actualizado: {u['email']}")
    else:
        cur.execute(
            """
            INSERT INTO usuarios (email, nombre, password_hash, rol, activo, creado_en)
            VALUES (?, ?, ?, ?, 1, datetime('now'))
            """,
            (u["email"], u["nombre"], generate_password_hash(u["password"]), u["rol"]),
        )
        usuario_id = cur.lastrowid
        print(f"Creado: {u['email']}")

    if u["rol"] == "evaluador":
        academicos = cur.execute("SELECT id FROM academicos").fetchall()
        for a in academicos:
            cur.execute(
                """
                INSERT OR IGNORE INTO asignaciones_evaluacion
                (academico_id, evaluador_id, estado, creado_en)
                VALUES (?, ?, 'pendiente', datetime('now'))
                """,
                (a["id"], usuario_id),
            )

conn.commit()
conn.close()

print("Listo. Recuerda cambiar estas contraseñas antes de usar datos reales.")

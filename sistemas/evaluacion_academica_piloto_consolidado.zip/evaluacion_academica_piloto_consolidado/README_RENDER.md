# Despliegue en Render — Piloto de Evaluación Académica por Comisión

Guía operativa para llevar la aplicación Flask + SQLite a un **Web Service pagado
de Render con Persistent Disk**.

Diseño, lógica funcional y motor de base de datos se mantienen sin cambios: solo
se preparó el arranque, la configuración y la persistencia.

---

## 0. Resumen de la arquitectura en producción

| Elemento | Valor |
|---|---|
| Servidor | Gunicorn (Render) |
| Base de datos | SQLite en disco persistente |
| Punto de montaje | `/var/data` |
| Ruta de la base | `/var/data/evaluacion.db` |
| Configuración | Variables de entorno (nada escrito en el código) |
| Carga de datos | Manual; `seed.py` **no** corre en el arranque |

Al iniciar, la aplicación:

1. crea la carpeta de la base si no existe;
2. crea **solo la estructura de tablas** si la base no existe;
3. si la base ya existe, aplica migraciones idempotentes y **no toca los datos**;
4. crea el usuario administrador **solo si la tabla `usuarios` está vacía**.

---

## 1. Correr localmente

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env              # Windows: copy .env.example .env
```

Edite `.env` para trabajo local:

```
SECRET_KEY=una-clave-local-cualquiera
DATABASE_PATH=data/evaluacion.db
FLASK_ENV=development
ADMIN_INITIAL_EMAIL=admin@usach.cl
ADMIN_INITIAL_PASSWORD=una-clave-local
```

> `FLASK_ENV=development` en local es importante: con `production` las cookies
> de sesión exigen HTTPS y no podrá iniciar sesión en `http://127.0.0.1`.

Ejecute:

```bash
python app.py
```

Abrir http://127.0.0.1:5000

### Datos de demostración (opcional, solo local)

`seed.py` es **destructivo**: borra la base y la recrea con los datos del mock-up.
Pide confirmación y exige una contraseña por entorno.

```bash
SEED_PASSWORD='clave-local-demo' python seed.py
```

Nunca lo ejecute contra la base del piloto en Render (queda bloqueado si
`FLASK_ENV=production`).

---

## 2. Probar con Gunicorn antes de subir

Esta es la misma forma en que Render ejecutará la aplicación. Conviene verificarla
localmente para descartar errores de arranque.

```bash
gunicorn app:app --bind 127.0.0.1:8000 --workers 1 --threads 4
```

Abrir http://127.0.0.1:8000 y comprobar login, evaluación, deliberación e informe.

> **Use 1 solo worker.** SQLite sobre un disco persistente no admite bien varios
> procesos escribiendo en paralelo. La concurrencia se resuelve con `--threads`,
> no con `--workers`. Para el volumen de una comisión evaluadora esto sobra.

---

## 3. Subir a un repositorio privado de GitHub

Verifique primero que no se suban secretos ni datos:

```bash
git init
git status          # NO deben aparecer .env, data/*.db ni backups/
```

Si `data/evaluacion.db` aparece en la lista, revise que `.gitignore` esté presente.

```bash
git add .
git commit -m "Preparación para despliegue en Render"
```

En GitHub cree un repositorio **privado** (por ejemplo `piloto-evaluacion-academica`)
y luego:

```bash
git remote add origin https://github.com/USUARIO/piloto-evaluacion-academica.git
git branch -M main
git push -u origin main
```

> El repositorio debe ser privado: aunque no contiene contraseñas, sí contiene la
> normativa, la rúbrica y la estructura del proceso de calificación.

---

## 4. Crear el Web Service en Render

1. Entrar a https://dashboard.render.com → **New** → **Web Service**.
2. Conectar la cuenta de GitHub y seleccionar el repositorio privado.
3. Configurar:

| Campo | Valor |
|---|---|
| Name | `piloto-evaluacion-academica` |
| Region | la más cercana (ej. Oregon) |
| Branch | `main` |
| Runtime | Python 3 |
| Build Command | `pip install -r requirements.txt` |
| Start Command | `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 120` |
| Instance Type | **un plan pagado** (los planes gratuitos no permiten disco persistente) |

4. Health Check Path (opcional, en *Advanced*): `/healthz`

---

## 5. Crear el Persistent Disk

En el servicio → **Disks** → **Add Disk**:

| Campo | Valor |
|---|---|
| Name | `datos-piloto` |
| Mount Path | `/var/data` |
| Size | 1 GB (suficiente y ampliable después) |

El disco sobrevive a cada redeploy. Todo lo que quede fuera de `/var/data` se
pierde en cada despliegue.

---

## 6. Configurar las variables de entorno

En el servicio → **Environment** → **Add Environment Variable**:

| Clave | Valor |
|---|---|
| `SECRET_KEY` | una cadena larga y aleatoria (ver abajo) |
| `DATABASE_PATH` | `/var/data/evaluacion.db` |
| `FLASK_ENV` | `production` |
| `ADMIN_INITIAL_EMAIL` | el correo institucional del administrador |
| `ADMIN_INITIAL_PASSWORD` | una contraseña temporal fuerte |
| `PYTHON_VERSION` | `3.11.9` |

Para generar la `SECRET_KEY`:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

Notas importantes:

- `DATABASE_PATH` **debe** apuntar dentro del punto de montaje `/var/data`.
- `ADMIN_INITIAL_PASSWORD` solo se usa la primera vez, cuando la base no tiene
  ningún usuario. Cambie esa contraseña al primer ingreso y luego puede borrar la
  variable del panel.
- Estas variables se cargan en Render; el archivo `.env` es únicamente local.

Guarde los cambios: Render redespliega automáticamente.

---

## 7. Primer ingreso

1. Abrir la URL `https://<su-servicio>.onrender.com`.
2. En **Logs** debe aparecer una línea similar a:
   `[bd] /var/data/evaluacion.db | Administrador inicial creado: ...`
3. Iniciar sesión con `ADMIN_INITIAL_EMAIL` y `ADMIN_INITIAL_PASSWORD`.
4. Cambiar la contraseña y crear los usuarios evaluadores, incluyendo al director como evaluador, desde el
   panel de administración.

Si los logs dicen *"Base sin usuarios. Defina ADMIN_INITIAL_EMAIL y
ADMIN_INITIAL_PASSWORD"*, falta configurar esas variables.

---

## 8. Respaldo de la base SQLite

El script `backup_db.py` usa la API de respaldo en línea de SQLite: se puede
ejecutar con el sistema en uso, sin detener el servicio.

### Desde el Shell de Render

Servicio → pestaña **Shell**:

```bash
python backup_db.py --destino /var/data/backups --conservar 30
```

Esto deja copias como `/var/data/backups/evaluacion_2026-08-07_14-32-05.db`.

### Descargar una copia a su computador

Desde el Shell de Render, sobre el archivo de respaldo:

```bash
base64 -w 0 /var/data/backups/evaluacion_2026-08-07_14-32-05.db > /tmp/copia.txt
cat /tmp/copia.txt
```

Copiar la salida y reconstruirla localmente:

```bash
base64 -d copia.txt > evaluacion_respaldo.db
sqlite3 evaluacion_respaldo.db "PRAGMA integrity_check;"
```

### Respaldo automático

Render → **New** → **Cron Job**, apuntando al mismo repositorio y con el mismo
disco montado:

- Schedule: `0 3 * * *` (03:00 diario)
- Command: `python backup_db.py --destino /var/data/backups --conservar 30`

> Antes de cada hito del piloto (cierre de evaluaciones individuales, cierre de
> deliberación, emisión de informes) conviene tomar un respaldo manual adicional
> y descargarlo fuera de Render.

---

## 9. Verificar que los datos persisten tras un redeploy

Prueba recomendada **antes** de cargar información real:

1. Ingresar al sistema y crear un dato reconocible (por ejemplo, un usuario
   evaluador de prueba o un borrador de evaluación).
2. Anotar la hora.
3. Forzar un redespliegue: **Manual Deploy** → **Clear build cache & deploy**,
   o hacer un commit menor y `git push`.
4. Esperar a que el servicio quede en *Live*.
5. Volver a ingresar y confirmar que el dato sigue ahí.
6. En los logs del nuevo despliegue debe aparecer
   `Ya existen usuarios: no se crea administrador inicial.`
   Esa línea confirma que la base **no** se recreó.

Verificación adicional desde el Shell:

```bash
ls -lh /var/data/
sqlite3 /var/data/evaluacion.db "SELECT COUNT(*) FROM usuarios;"
```

Si tras un redeploy la base aparece vacía, revise:

- que `DATABASE_PATH` apunte a `/var/data/evaluacion.db` (y no a `data/evaluacion.db`);
- que el disco esté montado exactamente en `/var/data`;
- que el Start Command no incluya `python seed.py`.

---

## 10. Errores frecuentes

| Síntoma | Causa probable | Solución |
|---|---|---|
| `RuntimeError: SECRET_KEY no está definida` | Falta la variable en Render | Agregarla en *Environment* |
| El login recarga sin entrar | Cookie segura sobre HTTP | En local use `FLASK_ENV=development` |
| `database is locked` | Varios workers de Gunicorn | Dejar `--workers 1` y usar `--threads` |
| La base se vacía en cada deploy | `DATABASE_PATH` fuera de `/var/data` | Corregir la variable |
| `no such table` | Base creada a medias | Revisar permisos del disco y reiniciar el servicio |

---

## 11. Cuando el piloto crezca

SQLite es adecuado para una comisión evaluadora trabajando sobre decenas de
académicos. Si el sistema se extiende a varias facultades en paralelo, el paso
siguiente es migrar a PostgreSQL (Render lo ofrece gestionado). El esquema actual
es compatible en lo esencial; ese cambio queda fuera de esta etapa.

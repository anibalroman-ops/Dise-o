"""Importador CLI integrado al mismo módulo que utiliza el panel web.

Uso:
    python importar_evidencias.py "/ruta/al/ZIP_DE_EVIDENCIAS.zip"
"""
import json
import sys
from pathlib import Path

from database import init_db
from importador import import_evidence_zip


def main():
    if len(sys.argv) != 2:
        print('Uso: python importar_evidencias.py "/ruta/al/archivo.zip"')
        return 2
    zip_path = Path(sys.argv[1]).expanduser().resolve()
    if not zip_path.is_file() or zip_path.suffix.lower() != '.zip':
        print(f'No se encontró un ZIP válido: {zip_path}')
        return 2
    init_db()
    import_id, report = import_evidence_zip(zip_path)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if report.get('errors') else 0


if __name__ == '__main__':
    raise SystemExit(main())

"""Importador consolidado de declaraciones anuales y evidencias.

Principios:
- Los Excel anuales son la única fuente de verdad para áreas, actividades y horas.
- Las carpetas/documentos NUNCA activan áreas ni crean porcentajes.
- La asociación documental es conservadora y auditable; lo ambiguo queda pendiente.
- No se requiere openpyxl: se leen directamente los XML internos de .xlsx.
"""

from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import re
import shutil
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZipFile

from werkzeug.utils import secure_filename

from catalogos import ACTIVITY_CATALOG, AREA_EXCEL_MAP, AREA_ORDER
from database import UPLOAD_ROOT, get_connection

NS = {
    'm': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
}
LECTIVE_WEEKS_YEAR = 36.0  # 18 semanas por semestre, consistente con fórmulas del Excel.
WORK_WEEKS_YEAR = 44.0     # divisor institucional usado en "HORAS EQ. SEMANALES".


def now():
    return datetime.now().isoformat(timespec='seconds')


def decode_zip_unicode(value: str) -> str:
    """Decodifica nombres entregados como DESEMPE#U00d1O -> DESEMPEÑO."""
    return re.sub(r'#U([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), value)


def normalize_text(value) -> str:
    value = decode_zip_unicode(str(value or '')).strip()
    value = unicodedata.normalize('NFD', value)
    value = ''.join(c for c in value if unicodedata.category(c) != 'Mn')
    value = re.sub(r'\s+', ' ', value).strip().upper()
    return value


def normalize_activity(value) -> str:
    return re.sub(r'\s+', ' ', str(value or '')).strip()


def num(value):
    if value in (None, ''):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        try:
            return float(str(value).replace(',', '.'))
        except (TypeError, ValueError):
            return None


def nz(value):
    return float(value or 0)


def fmt(value):
    if value is None:
        return ''
    value = float(value)
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    return f'{value:.2f}'.rstrip('0').rstrip('.')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_extract_zip(zip_path: Path, dest: Path):
    """Extrae evitando Zip Slip y decodificando los #Uxxxx del contenedor."""
    with ZipFile(zip_path) as zf:
        for info in zf.infolist():
            raw = decode_zip_unicode(info.filename).replace('\\', '/')
            pure = PurePosixPath(raw)
            if pure.is_absolute() or '..' in pure.parts:
                raise ValueError(f'Ruta insegura dentro del ZIP: {info.filename}')
            target = dest.joinpath(*pure.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open('wb') as out:
                shutil.copyfileobj(src, out)


class XlsxReader:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.cells = {}
        self.formulas = {}
        self.validations = []
        self.sheet_name = None
        self._read()

    def _read(self):
        with ZipFile(self.path) as z:
            shared = []
            if 'xl/sharedStrings.xml' in z.namelist():
                root = ET.fromstring(z.read('xl/sharedStrings.xml'))
                for si in root.findall('m:si', NS):
                    shared.append(''.join(t.text or '' for t in si.findall('.//m:t', NS)))

            workbook = ET.fromstring(z.read('xl/workbook.xml'))
            relroot = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
            rels = {r.attrib['Id']: r.attrib['Target'] for r in relroot}
            sheets = workbook.find('m:sheets', NS)
            selected = None
            for sheet in sheets:
                name = sheet.attrib['name']
                if normalize_text(name) == 'CONVENIO DESEMPENO':
                    selected = sheet
                    break
            selected = selected or list(sheets)[0]
            self.sheet_name = selected.attrib['name']
            rid = selected.attrib['{' + NS['r'] + '}id']
            target = rels[rid]
            if target.startswith('/'):
                target = target.lstrip('/')
            elif not target.startswith('xl/'):
                target = 'xl/' + target.lstrip('/')
            root = ET.fromstring(z.read(target))

            for cell in root.findall('.//m:sheetData/m:row/m:c', NS):
                ref = cell.attrib['r']
                typ = cell.attrib.get('t')
                v = cell.find('m:v', NS)
                f = cell.find('m:f', NS)
                if f is not None:
                    self.formulas[ref] = f.text
                if typ == 'inlineStr':
                    value = ''.join(t.text or '' for t in cell.findall('.//m:t', NS))
                elif v is None:
                    value = None
                else:
                    raw = v.text
                    if typ == 's':
                        value = shared[int(raw)]
                    elif typ == 'b':
                        value = raw == '1'
                    elif typ in ('str', 'e'):
                        value = raw
                    else:
                        try:
                            value = float(raw)
                        except (TypeError, ValueError):
                            value = raw
                self.cells[ref] = value

            for dv in root.findall('.//m:dataValidations/m:dataValidation', NS):
                f = dv.find('m:formula1', NS)
                self.validations.append({
                    'sqref': dv.attrib.get('sqref'),
                    'type': dv.attrib.get('type'),
                    'formula1': f.text if f is not None else None,
                })

    def get(self, col, row):
        return self.cells.get(f'{col}{row}')

    def row_value(self, row, cols='ABCDEFGHIJKLMN'):
        return [self.get(col, row) for col in cols]


def canonical_hierarchy(raw):
    text = normalize_text(raw)
    for key, label in [
        ('TITULAR', 'Titular'), ('ASOCIADO', 'Asociado'), ('ASISTENTE', 'Asistente'),
        ('INSTRUCTOR', 'Instructor'), ('AYUDANTE', 'Ayudante')
    ]:
        if key in text:
            return label
    return normalize_activity(raw).title() or 'No informada'


def canonical_jornada(raw):
    text = normalize_text(raw)
    if 'COMPLETA' in text:
        return 'Jornada Completa'
    if text in ('3/4', 'TRES CUARTOS'):
        return '3/4 Jornada'
    if text in ('1/2', 'MEDIA'):
        return '1/2 Jornada'
    if text in ('1/4',):
        return '1/4 Jornada'
    return normalize_activity(raw).title() or 'No informada'


def _area_key(raw):
    return AREA_EXCEL_MAP.get(normalize_text(raw))


def _summary_rows(reader: XlsxReader):
    result = {}
    for row in range(15, 32):
        area = _area_key(reader.get('B', row))
        if not area:
            continue
        result[area] = {
            'source_row': row,
            'comp_semana_excel': nz(num(reader.get('F', row))),
            'comp_anual_excel': nz(num(reader.get('G', row))),
            'real_semana_excel': nz(num(reader.get('H', row))),
            'real_anual_excel': nz(num(reader.get('I', row))),
            'equiv_semana_real_excel': nz(num(reader.get('J', row))),
        }
    return result


def _find_area_spans(reader: XlsxReader):
    headers = []
    for row in range(30, 260):
        area = _area_key(reader.get('B', row))
        if area:
            headers.append((row, area))
    spans = []
    for i, (start, area) in enumerate(headers):
        next_header = headers[i + 1][0] if i + 1 < len(headers) else 300
        total_row = None
        for row in range(start + 1, next_header):
            text = normalize_text(reader.get('B', row))
            if text.startswith('TOTAL '):
                total_row = row
                break
        if not total_row:
            # La administración incluye un subbloque; su total aparece antes del siguiente área.
            for row in range(start + 1, next_header):
                if normalize_text(reader.get('B', row)).startswith('TOTAL'):
                    total_row = row
                    break
        spans.append((start, total_row or next_header, area))
    return spans


def parse_excel(path: Path):
    reader = XlsxReader(path)
    warnings = []

    year = int(num(reader.get('G', 7)) or 0)
    if year < 2000 or year > 2100:
        match = re.search(r'(20\d{2})', decode_zip_unicode(path.name))
        if not match:
            raise ValueError(f'No se pudo determinar el año de {path.name}')
        year = int(match.group(1))
        warnings.append('El año se obtuvo del nombre del archivo porque G7 no era utilizable.')

    apellido_paterno = normalize_activity(reader.get('C', 10))
    nombres = normalize_activity(reader.get('I', 10))
    full_name = ' '.join(x for x in [nombres, apellido_paterno] if x).strip()
    if not full_name:
        full_name = normalize_activity(reader.get('D', 32)) or 'Académico sin nombre'
        warnings.append('No se pudieron leer C10/I10; se usó el nombre del bloque de firmas.')

    identity = {
        'nombre': full_name.title() if full_name.isupper() else full_name,
        'apellido_paterno': apellido_paterno.title() if apellido_paterno.isupper() else apellido_paterno,
        'apellido_materno': '',
        'nombres': nombres.title() if nombres.isupper() else nombres,
        'departamento': normalize_activity(reader.get('E', 13)).title(),
        'jerarquia': canonical_hierarchy(reader.get('I', 13)),
        'jornada': canonical_jornada(reader.get('K', 13)),
    }

    summary_excel = _summary_rows(reader)
    area_spans = _find_area_spans(reader)
    if len(area_spans) < 7:
        warnings.append(f'Se detectaron {len(area_spans)} de 7 bloques de área esperados.')

    areas = []
    for start, end, area_name in area_spans:
        activities = []
        for row in range(start + 1, end):
            raw_name = reader.get('B', row)
            if not isinstance(raw_name, str) or not raw_name.strip():
                continue
            norm = normalize_text(raw_name)
            if norm.startswith(('TOTAL ', 'PRIMER SEMESTRE', 'SEGUNDO SEMESTRE', 'COMPROMETIDO', 'REALIZADO')):
                continue
            if norm == 'ADMINISTRACION ACADEMICA DEPARTAMENTAL':
                continue
            vals = [num(reader.get(col, row)) for col in 'FGHIJKLM']
            observation = normalize_activity(reader.get('N', row))
            has_data = any(v is not None for v in vals) or bool(observation)
            if not has_data:
                continue
            activity = {
                'source_row': row,
                'actividad': normalize_activity(raw_name),
                'contexto': '',
                's1_comp_hsemana': vals[0],
                's1_comp_hsemestre': vals[1],
                's1_real_hsemana': vals[2],
                's1_real_hsemestre': vals[3],
                's2_comp_hsemana': vals[4],
                's2_comp_hsemestre': vals[5],
                's2_real_hsemana': vals[6],
                's2_real_hsemestre': vals[7],
                'observacion': observation,
                'evidencia_textual': '',
            }
            # Los 0 explícitos del 1er semestre 2023 se conservan como 0; los vacíos se conservan como None.
            activities.append(activity)

        comp_annual = sum(
            (nz(a['s1_comp_hsemana']) + nz(a['s2_comp_hsemana'])) * 18.0
            + nz(a['s1_comp_hsemestre']) + nz(a['s2_comp_hsemestre'])
            for a in activities
        )
        real_annual = sum(
            (nz(a['s1_real_hsemana']) + nz(a['s2_real_hsemana'])) * 18.0
            + nz(a['s1_real_hsemestre']) + nz(a['s2_real_hsemestre'])
            for a in activities
        )
        raw_summary = summary_excel.get(area_name, {})
        expected_comp = raw_summary.get('comp_semana_excel', 0) * LECTIVE_WEEKS_YEAR + raw_summary.get('comp_anual_excel', 0)
        expected_real = raw_summary.get('real_semana_excel', 0) * LECTIVE_WEEKS_YEAR + raw_summary.get('real_anual_excel', 0)
        if abs(comp_annual - expected_comp) > 0.11:
            warnings.append(
                f'{year} · {area_name}: la suma de actividades comprometidas ({comp_annual:.1f} h) '
                f'no cuadra con el resumen del Excel ({expected_comp:.1f} h).'
            )
        if abs(real_annual - expected_real) > 0.11:
            warnings.append(
                f'{year} · {area_name}: la suma de actividades realizadas ({real_annual:.1f} h) '
                f'no cuadra con el resumen del Excel ({expected_real:.1f} h).'
            )

        areas.append({
            'nombre': area_name,
            'source_row': start,
            'activities': activities,
            'horas_comprometidas_anuales': comp_annual,
            'horas_realizadas_anuales': real_annual,
            'promedio_semanal_comprometido': comp_annual / WORK_WEEKS_YEAR,
            'promedio_semanal_realizado': real_annual / WORK_WEEKS_YEAR,
            **raw_summary,
        })

    # Se crean también áreas faltantes en cero para mantener el catálogo completo, sin activarlas.
    present = {a['nombre'] for a in areas}
    for area_name in AREA_ORDER:
        if area_name not in present:
            areas.append({
                'nombre': area_name, 'source_row': None, 'activities': [],
                'horas_comprometidas_anuales': 0.0, 'horas_realizadas_anuales': 0.0,
                'promedio_semanal_comprometido': 0.0, 'promedio_semanal_realizado': 0.0,
                'comp_semana_excel': 0.0, 'comp_anual_excel': 0.0,
                'real_semana_excel': 0.0, 'real_anual_excel': 0.0,
            })
    areas.sort(key=lambda a: AREA_ORDER.index(a['nombre']))

    total_comp = sum(a['horas_comprometidas_anuales'] for a in areas)
    total_real = sum(a['horas_realizadas_anuales'] for a in areas)
    for area in areas:
        area['porcentaje_comprometido'] = (area['horas_comprometidas_anuales'] / total_comp * 100) if total_comp else 0.0
        area['porcentaje_realizado'] = (area['horas_realizadas_anuales'] / total_real * 100) if total_real else 0.0

    # Verifica específicamente la anomalía conocida de Educación Continua.
    for dv in reader.validations:
        if dv['type'] == 'list' and dv.get('sqref') and 'B157' in dv['sqref'] and dv.get('formula1') == '$P$34:$P$62':
            warnings.append(
                'Educación Continua usa en este Excel la misma validación de lista que Docencia. '
                'El sistema NO hereda esa lista y mantiene Educación Continua como catálogo abierto.'
            )
            break

    return {
        'year': year,
        'identity': identity,
        'sheet_name': reader.sheet_name,
        'source_file': decode_zip_unicode(path.name),
        'source_sha256': sha256_file(path),
        'areas': areas,
        'warnings': warnings,
    }


def _next_person_code(db):
    max_n = 0
    for row in db.execute('SELECT codigo FROM personas_academicas').fetchall():
        m = re.fullmatch(r'A-(\d+)', row['codigo'] or '')
        if m:
            max_n = max(max_n, int(m.group(1)))
    return f'A-{max_n + 1:03d}'


def _find_or_create_person(db, parsed_by_year):
    first = parsed_by_year[min(parsed_by_year)]
    identity = first['identity']
    wanted = normalize_text(identity['nombre'])
    for row in db.execute('SELECT * FROM personas_academicas').fetchall():
        if normalize_text(row['nombre']) == wanted:
            return row['id'], row['codigo'], False

    code = _next_person_code(db)
    ts = now()
    cur = db.execute(
        """
        INSERT INTO personas_academicas
        (codigo, nombre, apellido_paterno, apellido_materno, nombres, departamento_base,
         anio_ingreso, creado_en, actualizado_en)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            code, identity['nombre'], identity['apellido_paterno'], identity['apellido_materno'],
            identity['nombres'], identity['departamento'], min(parsed_by_year), ts, ts,
        ),
    )
    return cur.lastrowid, code, True


def _can_replace_evaluation(db, evaluation_id):
    n = db.execute(
        """
        SELECT
          (SELECT COUNT(*) FROM asignaciones_evaluacion ae
             JOIN evaluaciones_individuales ei ON ei.asignacion_id = ae.id
           WHERE ae.academico_id = ?) +
          (SELECT COUNT(*) FROM evaluacion_final_comision ef
             JOIN areas_compromiso ac ON ac.id = ef.area_id
           WHERE ac.academico_id = ?) AS n
        """,
        (evaluation_id, evaluation_id),
    ).fetchone()['n']
    return n == 0


def _insert_or_replace_year(db, persona_id, person_code, parsed, warnings):
    year = parsed['year']
    evaluation = db.execute(
        'SELECT * FROM academicos WHERE persona_id = ? AND anio_evaluacion = ?',
        (persona_id, year),
    ).fetchone()
    if not evaluation:
        # Compatibilidad con una eventual importación previa creada por código.
        evaluation = db.execute('SELECT * FROM academicos WHERE codigo = ?', (f'{person_code}-{year}',)).fetchone()

    identity = parsed['identity']
    code = f'{person_code}-{year}'
    if evaluation:
        if not _can_replace_evaluation(db, evaluation['id']):
            warnings.append(
                f'{year}: existe una evaluación con borradores/envíos; no se reemplazaron áreas ni actividades.'
            )
            return evaluation['id'], code, False
        # Una reimportación reemplaza solo evidencias provenientes del ZIP. Las cargas manuales se conservan.
        # Como las actividades/áreas serán reconstruidas, una evidencia manual ligada a ellas se degrada
        # de forma segura al nivel de evaluación para evitar referencias semánticamente obsoletas.
        manual_linked = db.execute(
            "SELECT COUNT(*) AS n FROM evidencias WHERE evaluacion_id=? AND origen='carga manual' AND (area_id IS NOT NULL OR actividad_id IS NOT NULL)",
            (evaluation['id'],),
        ).fetchone()['n']
        if manual_linked:
            db.execute(
                "UPDATE evidencias SET area_id=NULL, actividad_id=NULL, estado_asociacion='evaluacion' WHERE evaluacion_id=? AND origen='carga manual'",
                (evaluation['id'],),
            )
            warnings.append(f'{year}: {manual_linked} evidencia(s) manual(es) se conservaron a nivel de evaluación al reconstruir áreas/actividades.')
        db.execute("DELETE FROM evidencias WHERE evaluacion_id = ? AND COALESCE(origen,'') <> 'carga manual'", (evaluation['id'],))
        db.execute('DELETE FROM areas_compromiso WHERE academico_id = ?', (evaluation['id'],))
        db.execute(
            """
            UPDATE academicos SET persona_id=?, codigo_base=?, nombre=?, codigo=?, jerarquia=?, jornada=?,
                departamento=?, periodo=?, anio_evaluacion=?, source_excel=?, source_excel_sha256=?, importado_en=?
            WHERE id=?
            """,
            (
                persona_id, person_code, identity['nombre'], code, identity['jerarquia'], identity['jornada'],
                identity['departamento'], str(year), year, parsed['source_file'], parsed['source_sha256'], now(), evaluation['id'],
            ),
        )
        evaluation_id = evaluation['id']
    else:
        cur = db.execute(
            """
            INSERT INTO academicos
            (codigo, jerarquia, jornada, departamento, periodo, anio_ingreso, creado_en,
             persona_id, codigo_base, nombre, anio_evaluacion, source_excel, source_excel_sha256, importado_en)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                code, identity['jerarquia'], identity['jornada'], identity['departamento'], str(year),
                year, now(), persona_id, person_code, identity['nombre'], year,
                parsed['source_file'], parsed['source_sha256'], now(),
            ),
        )
        evaluation_id = cur.lastrowid

    for area in parsed['areas']:
        weight = area['porcentaje_comprometido'] if sum(a['horas_comprometidas_anuales'] for a in parsed['areas']) else area['porcentaje_realizado']
        cur = db.execute(
            """
            INSERT INTO areas_compromiso
            (academico_id, nombre, horas_semana, horas_anio, peso, estado,
             horas_comprometidas_anuales, horas_realizadas_anuales,
             promedio_semanal_comprometido, promedio_semanal_realizado,
             porcentaje_comprometido, porcentaje_realizado,
             resumen_excel_comp_semana, resumen_excel_comp_anual,
             resumen_excel_real_semana, resumen_excel_real_anual, source_row)
            VALUES (?, ?, ?, ?, ?, 'Pendiente', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                evaluation_id, area['nombre'], area['promedio_semanal_comprometido'],
                area['horas_comprometidas_anuales'], weight,
                area['horas_comprometidas_anuales'], area['horas_realizadas_anuales'],
                area['promedio_semanal_comprometido'], area['promedio_semanal_realizado'],
                area['porcentaje_comprometido'], area['porcentaje_realizado'],
                area.get('comp_semana_excel', 0), area.get('comp_anual_excel', 0),
                area.get('real_semana_excel', 0), area.get('real_anual_excel', 0), area.get('source_row'),
            ),
        )
        area_id = cur.lastrowid
        for act in area['activities']:
            legacy_s1 = f"{fmt(act['s1_real_hsemana'])} / {fmt(act['s1_real_hsemestre'])}"
            legacy_s2 = f"{fmt(act['s2_real_hsemana'])} / {fmt(act['s2_real_hsemestre'])}"
            db.execute(
                """
                INSERT INTO actividades_comprometidas
                (area_id, actividad, contexto, primer_semestre, segundo_semestre, observacion, evidencia,
                 s1_comp_hsemana, s1_comp_hsemestre, s1_real_hsemana, s1_real_hsemestre,
                 s2_comp_hsemana, s2_comp_hsemestre, s2_real_hsemana, s2_real_hsemestre,
                 anio, evidencia_textual, source_row, source_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    area_id, act['actividad'], act['contexto'], legacy_s1, legacy_s2,
                    act['observacion'], act['evidencia_textual'],
                    act['s1_comp_hsemana'], act['s1_comp_hsemestre'], act['s1_real_hsemana'], act['s1_real_hsemestre'],
                    act['s2_comp_hsemana'], act['s2_comp_hsemestre'], act['s2_real_hsemana'], act['s2_real_hsemestre'],
                    year, act['evidencia_textual'], act['source_row'], json.dumps(act, ensure_ascii=False),
                ),
            )
    return evaluation_id, code, True


def recalculate_evaluation(db, evaluation_id):
    areas = db.execute('SELECT * FROM areas_compromiso WHERE academico_id = ? ORDER BY id', (evaluation_id,)).fetchall()
    computed = []
    for area in areas:
        acts = db.execute('SELECT * FROM actividades_comprometidas WHERE area_id = ?', (area['id'],)).fetchall()
        comp = real = 0.0
        for a in acts:
            comp += (nz(a['s1_comp_hsemana']) + nz(a['s2_comp_hsemana'])) * 18.0 + nz(a['s1_comp_hsemestre']) + nz(a['s2_comp_hsemestre'])
            real += (nz(a['s1_real_hsemana']) + nz(a['s2_real_hsemana'])) * 18.0 + nz(a['s1_real_hsemestre']) + nz(a['s2_real_hsemestre'])
        computed.append((area['id'], comp, real))
    total_comp = sum(x[1] for x in computed)
    total_real = sum(x[2] for x in computed)
    for area_id, comp, real in computed:
        pc = comp / total_comp * 100 if total_comp else 0.0
        pr = real / total_real * 100 if total_real else 0.0
        weight = pc if total_comp else pr
        db.execute(
            """
            UPDATE areas_compromiso SET
              horas_comprometidas_anuales=?, horas_realizadas_anuales=?,
              promedio_semanal_comprometido=?, promedio_semanal_realizado=?,
              porcentaje_comprometido=?, porcentaje_realizado=?,
              horas_semana=?, horas_anio=?, peso=?
            WHERE id=?
            """,
            (comp, real, comp / WORK_WEEKS_YEAR, real / WORK_WEEKS_YEAR,
             pc, pr, comp / WORK_WEEKS_YEAR, comp, weight, area_id),
        )


def _years_from_path(rel_path: str, valid_years):
    rel = decode_zip_unicode(rel_path)
    base = os.path.basename(rel)
    explicit = sorted({int(y) for y in re.findall(r'(?<!\d)(20\d{2})(?!\d)', base) if int(y) in valid_years})
    if explicit:
        return explicit, 'nombre de archivo'
    ranges = re.findall(r'(20\d{2})\s*[-–_]\s*(20\d{2})', rel)
    years = set()
    for a, b in ranges:
        a, b = int(a), int(b)
        for year in range(min(a, b), max(a, b) + 1):
            if year in valid_years:
                years.add(year)
    if years:
        return sorted(years), 'rango en carpeta'
    years = sorted({int(y) for y in re.findall(r'(?<!\d)(20\d{2})(?!\d)', rel) if int(y) in valid_years})
    return years, ('carpeta' if years else None)


def _suggest_area(rel_path: str):
    text = normalize_text(rel_path)
    # Primero se respetan carpetas temáticas explícitas. Así, por ejemplo,
    # "Cursos/Curso paper writing.pdf" sigue siendo Perfeccionamiento y no se
    # confunde con Investigación solo porque el nombre contiene la palabra paper.
    if 'CURSOS' in text or 'CAPACITACION' in text:
        return 'Perfeccionamiento'
    if 'CLASES' in text or 'ASIGNATURAS' in text or 'TITULACION' in text:
        return 'Docencia'
    if 'SOCIAL' in text or 'TALK' in text or 'SEMINAR' in text:
        return 'Extensión - VIME'
    if any(word in text for word in ('PAPERS', 'PAPER', 'CAPITULO', 'JOURNAL', 'DICYT', 'PROJECT', 'PROYECT', 'LABORATORIO COMPLEX')):
        return 'Investigación y Desarrollo'
    return None


def _activity_score(activity, rel_path, suggested_area):
    path = normalize_text(rel_path)
    name = normalize_text(activity['actividad'])
    obs = normalize_text(activity['observacion'])
    score = 0
    if suggested_area == 'Docencia':
        if 'TITULACION' in path:
            # No convertir una evidencia de titulación en evidencia de docencia
            # directa si esa actividad no fue declarada en el Excel.
            if 'TITULACION' in name:
                score += 12
            return score
        if any(x in path for x in ('CLASE', 'ASIGNATURA', 'SDD')) and 'DOCENCIA DIRECTA' in name:
            score += 8
    elif suggested_area == 'Investigación y Desarrollo':
        if 'CAPITULO' in path and 'CAPITULO' in obs:
            score += 12
        if 'LABORATORIO' in path and 'LABORATORIO' in obs:
            score += 12
        if 'PAPER' in path:
            if 'PAPER' in obs:
                score += 12
            if 'PUBLICA' in obs:
                score += 10
            if 'PRODUCTOS DE LOS PROYECTOS' in name:
                score += 4
            if 'PUBLICACION DE TRABAJOS' in name:
                score += 4
        if 'DICYT' in path:
            if 'DICYT' in obs:
                score += 12
            if 'PROYECT' in name:
                score += 4
    elif suggested_area == 'Perfeccionamiento':
        if 'CURSO' in path and 'CURSO DE CAPACITACION' in name:
            score += 12
    return score


def _active_area(db, evaluation_id, area_name):
    return db.execute(
        """
        SELECT * FROM areas_compromiso
        WHERE academico_id=? AND nombre=?
          AND (horas_comprometidas_anuales > 0 OR horas_realizadas_anuales > 0)
        """,
        (evaluation_id, area_name),
    ).fetchone()


def _best_activity(db, area_id, rel_path, suggested_area):
    activities = db.execute('SELECT * FROM actividades_comprometidas WHERE area_id=? ORDER BY id', (area_id,)).fetchall()
    scored = sorted(((_activity_score(a, rel_path, suggested_area), a) for a in activities), key=lambda x: x[0], reverse=True)
    if not scored or scored[0][0] < 8:
        return None
    # Si hay empate fuerte, es más seguro dejar la evidencia a nivel de área.
    if len(scored) > 1 and scored[1][0] == scored[0][0]:
        return None
    return scored[0][1]


def _safe_stored_rel(person_code, stamp, source_rel, digest):
    parts = []
    for piece in PurePosixPath(decode_zip_unicode(source_rel).replace('\\', '/')).parts:
        safe = secure_filename(piece) or 'archivo'
        parts.append(safe)
    filename = parts[-1]
    stem, ext = os.path.splitext(filename)
    parts[-1] = f'{stem}_{digest[:10]}{ext.lower()}'
    return str(PurePosixPath(person_code, f'import_{stamp}', *parts))


def _store_evidence_files(db, evidence_root: Path, persona_id, person_code, evaluations, report):
    valid_years = sorted(evaluations)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique_files = 0
    evidence_records = 0
    pending = 0
    area_only = 0
    activity_linked = 0

    files = [p for p in evidence_root.rglob('*') if p.is_file() and p.suffix.lower() not in ('.xlsx', '.xls')]
    for file_path in sorted(files):
        unique_files += 1
        source_rel = file_path.relative_to(evidence_root).as_posix()
        decoded_rel = decode_zip_unicode(source_rel)
        digest = sha256_file(file_path)
        stored_rel = _safe_stored_rel(person_code, stamp, decoded_rel, digest)
        target = Path(UPLOAD_ROOT) / stored_rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copy2(file_path, target)

        years, year_reason = _years_from_path(decoded_rel, valid_years)
        suggested_area = _suggest_area(decoded_rel)

        # Si no hay año explícito, solo inferimos cuando el área sugerida está activa
        # en exactamente un año. Esto no crea ni activa áreas: solo asocia evidencia.
        if not years and suggested_area:
            candidates = [y for y, eid in evaluations.items() if _active_area(db, eid, suggested_area)]
            if len(candidates) == 1:
                years = candidates
                year_reason = 'único año con el área declarada activa'
                report['warnings'].append(
                    f'Evidencia "{os.path.basename(decoded_rel)}": año inferido como {years[0]} '
                    f'porque {suggested_area} solo está activa ese año.'
                )

        associations = years or [None]
        for year in associations:
            evaluation_id = evaluations.get(year) if year else None
            area_id = None
            activity_id = None
            state = 'pendiente'
            description_bits = []
            if year_reason:
                description_bits.append(f'Año inferido por {year_reason}.')
            if suggested_area:
                description_bits.append(f'Área sugerida por carpeta/nombre: {suggested_area}.')

            if evaluation_id and suggested_area:
                area = _active_area(db, evaluation_id, suggested_area)
                if area:
                    area_id = area['id']
                    activity = _best_activity(db, area_id, decoded_rel, suggested_area)
                    if activity:
                        activity_id = activity['id']
                        state = 'actividad'
                        activity_linked += 1
                    else:
                        state = 'area'
                        area_only += 1
                else:
                    description_bits.append('No se asoció al área porque el Excel de ese año no la declara activa.')

            if not evaluation_id:
                pending += 1
            elif not area_id:
                pending += 1

            mime_type = mimetypes.guess_type(file_path.name)[0] or 'application/octet-stream'
            db.execute(
                """
                INSERT INTO evidencias
                (persona_id, evaluacion_id, anio, area_id, actividad_id, titulo, descripcion,
                 nombre_original, nombre_guardado, ruta_relativa, extension, mime_type, tamano,
                 fecha_carga, origen, estado_asociacion)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    persona_id, evaluation_id, year, area_id, activity_id,
                    decode_zip_unicode(file_path.name), ' '.join(description_bits),
                    decode_zip_unicode(file_path.name), os.path.basename(stored_rel), stored_rel,
                    file_path.suffix.lower(), mime_type, file_path.stat().st_size, now(), decoded_rel, state,
                ),
            )
            evidence_records += 1

    report['evidencias_archivos_unicos'] = unique_files
    report['evidencias_registros'] = evidence_records
    report['evidencias_actividad'] = activity_linked
    report['evidencias_solo_area'] = area_only
    report['evidencias_pendientes'] = pending


def import_evidence_zip(zip_path, usuario_id=None, original_name=None):
    zip_path = Path(zip_path)
    original_name = original_name or zip_path.name
    with get_connection() as db:
        cur = db.execute(
            """
            INSERT INTO importaciones (usuario_id, archivo_zip, iniciado_en, estado)
            VALUES (?, ?, ?, 'procesando')
            """,
            (usuario_id, original_name, now()),
        )
        import_id = cur.lastrowid
        db.commit()

    report = {
        'importacion_id': import_id,
        'archivo_zip': original_name,
        'formula_carga': 'horas_anuales = (h/sem S1 + h/sem S2) × 18 + h/semestre S1 + h/semestre S2; promedio semanal anual = horas_anuales / 44',
        'years_detected': [],
        'evaluations': [],
        'warnings': [],
        'errors': [],
    }

    try:
        with tempfile.TemporaryDirectory(prefix='eval_acad_') as tmp:
            root = Path(tmp) / 'contenido'
            root.mkdir(parents=True)
            safe_extract_zip(zip_path, root)
            excel_files = sorted(root.rglob('*.xlsx'))
            parsed = {}
            for path in excel_files:
                try:
                    item = parse_excel(path)
                    if item['year'] in parsed:
                        report['warnings'].append(f'Se encontró más de un Excel para {item["year"]}; se conservó el primero.')
                        continue
                    parsed[item['year']] = item
                    report['warnings'].extend(item['warnings'])
                except Exception as exc:
                    report['errors'].append(f'No se pudo leer {decode_zip_unicode(path.name)}: {exc}')

            if not parsed:
                raise ValueError('El ZIP no contiene Excel anuales reconocibles.')

            report['years_detected'] = sorted(parsed)
            with get_connection() as db:
                persona_id, person_code, person_created = _find_or_create_person(db, parsed)
                report['persona_id'] = persona_id
                report['codigo_persona'] = person_code
                report['persona_creada'] = person_created
                evaluations = {}
                for year in sorted(parsed):
                    evaluation_id, code, replaced = _insert_or_replace_year(db, persona_id, person_code, parsed[year], report['warnings'])
                    evaluations[year] = evaluation_id
                    areas = parsed[year]['areas']
                    active = [a for a in areas if a['horas_comprometidas_anuales'] > 0 or a['horas_realizadas_anuales'] > 0]
                    report['evaluations'].append({
                        'year': year,
                        'codigo': code,
                        'evaluation_id': evaluation_id,
                        'importada': replaced,
                        'areas_activas': [a['nombre'] for a in active],
                        'actividades_importadas': sum(len(a['activities']) for a in areas),
                        'horas_comprometidas_anuales': round(sum(a['horas_comprometidas_anuales'] for a in areas), 2),
                        'horas_realizadas_anuales': round(sum(a['horas_realizadas_anuales'] for a in areas), 2),
                        'areas': [
                            {
                                'nombre': a['nombre'],
                                'activa': a['horas_comprometidas_anuales'] > 0 or a['horas_realizadas_anuales'] > 0,
                                'actividades': len(a['activities']),
                                'h_comp_anuales': round(a['horas_comprometidas_anuales'], 2),
                                'h_real_anuales': round(a['horas_realizadas_anuales'], 2),
                                'pct_comp': round(a['porcentaje_comprometido'], 2),
                                'pct_real': round(a['porcentaje_realizado'], 2),
                            }
                            for a in areas
                        ],
                    })

                # El root puede contener una carpeta contenedora; la asociación usa toda la ruta relativa.
                _store_evidence_files(db, root, persona_id, person_code, evaluations, report)
                db.execute(
                    'UPDATE importaciones SET persona_id=?, finalizado_en=?, estado=?, reporte_json=? WHERE id=?',
                    (persona_id, now(), 'completada', json.dumps(report, ensure_ascii=False), import_id),
                )
                db.commit()

    except (BadZipFile, ValueError, Exception) as exc:
        # El except amplio es intencional aquí: deja un reporte persistente aun si falla la importación.
        report['errors'].append(str(exc))
        with get_connection() as db:
            db.execute(
                'UPDATE importaciones SET finalizado_en=?, estado=?, reporte_json=? WHERE id=?',
                (now(), 'error', json.dumps(report, ensure_ascii=False), import_id),
            )
            db.commit()
    return import_id, report

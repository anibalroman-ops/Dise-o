"""Respaldo de la base SQLite del piloto de evaluación académica.

Uso:
    python backup_db.py                      # respalda a backups/
    python backup_db.py --destino /var/data/backups
    python backup_db.py --conservar 30       # mantiene solo los 30 más recientes

Usa la API de respaldo en línea de SQLite, por lo que es seguro ejecutarlo con la
aplicación en funcionamiento: no interrumpe el servicio ni deja la copia a medias.
La ruta de origen se toma de DATABASE_PATH (igual que la aplicación).
"""

import argparse
import os
import sqlite3
import sys
from datetime import datetime

from database import DB_PATH


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DESTINO_POR_DEFECTO = os.environ.get("BACKUP_PATH", "").strip() or os.path.join(BASE_DIR, "backups")


def respaldar(origen=DB_PATH, destino=DESTINO_POR_DEFECTO):
    if not os.path.exists(origen):
        raise SystemExit(f"No se encontró la base de datos en: {origen}")

    os.makedirs(destino, exist_ok=True)

    marca = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    nombre = os.path.splitext(os.path.basename(origen))[0]
    ruta_copia = os.path.join(destino, f"{nombre}_{marca}.db")

    conn_origen = sqlite3.connect(f"file:{origen}?mode=ro", uri=True)
    conn_copia = sqlite3.connect(ruta_copia)
    try:
        with conn_copia:
            conn_origen.backup(conn_copia)
    finally:
        conn_copia.close()
        conn_origen.close()

    return ruta_copia


def limpiar_antiguos(destino, conservar):
    if conservar is None or conservar <= 0:
        return []

    archivos = sorted(
        (os.path.join(destino, f) for f in os.listdir(destino) if f.endswith(".db")),
        key=os.path.getmtime,
        reverse=True,
    )
    eliminados = archivos[conservar:]
    for ruta in eliminados:
        os.remove(ruta)
    return eliminados


def main():
    parser = argparse.ArgumentParser(description="Respalda la base SQLite del piloto.")
    parser.add_argument("--origen", default=DB_PATH, help="Ruta de la base a respaldar.")
    parser.add_argument("--destino", default=DESTINO_POR_DEFECTO, help="Carpeta de respaldos.")
    parser.add_argument(
        "--conservar",
        type=int,
        default=None,
        help="Cantidad máxima de respaldos a mantener (los más antiguos se eliminan).",
    )
    args = parser.parse_args()

    ruta = respaldar(args.origen, args.destino)
    tamano_kb = os.path.getsize(ruta) / 1024
    print(f"Respaldo creado: {ruta} ({tamano_kb:.1f} KB)")

    eliminados = limpiar_antiguos(args.destino, args.conservar)
    for ruta_eliminada in eliminados:
        print(f"Respaldo antiguo eliminado: {os.path.basename(ruta_eliminada)}")

    return 0


if __name__ == "__main__":
    sys.exit(main())

# Corrección de acceso admin

Esta versión no incluye `data/evaluacion.db`. La base debe crearse localmente desde `.env`.

## Inicio limpio recomendado

1. Cree `.env` en la carpeta raíz con:

```env
SECRET_KEY=clave-local-de-prueba-cambiar-despues
DATABASE_PATH=data/evaluacion.db
FLASK_ENV=production
ADMIN_INITIAL_EMAIL=admin@piloto.cl
ADMIN_INITIAL_PASSWORD=ClaveInicialSegura123
```

2. Si existe una base antigua, elimínela:

```powershell
Remove-Item data\evaluacion.db -ErrorAction SilentlyContinue
Remove-Item data\evaluacion.db-wal -ErrorAction SilentlyContinue
Remove-Item data\evaluacion.db-shm -ErrorAction SilentlyContinue
```

3. Ejecute:

```powershell
python app.py
```

4. Ingrese con el correo y contraseña definidos en `.env`.

## Si la base ya tiene datos y no quiere borrarla

Ejecute:

```powershell
python reset_admin.py
```

Luego vuelva a iniciar la app e ingrese con el admin definido en `.env`.

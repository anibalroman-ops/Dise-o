import hashlib
import json
import mimetypes
import os
import sys
import tempfile
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timedelta
from functools import wraps
from urllib.parse import urlparse

from dotenv import load_dotenv
from flask import Flask, abort, flash, redirect, render_template, request, send_from_directory, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

# Cargar .env antes de importar database.py, porque database.py resuelve DATABASE_PATH al importarse.
load_dotenv()

from database import DB_PATH, UPLOAD_ROOT, bootstrap_database, get_connection, log_event
from catalogos import ACTIVITY_CATALOG, AREA_ORDER
from importador import import_evidence_zip, recalculate_evaluation

IS_PRODUCTION = os.environ.get("FLASK_ENV", "development").lower() == "production"

app = Flask(__name__)

# --- SECRET_KEY -------------------------------------------------------------
_secret = os.environ.get("SECRET_KEY", "").strip()
if not _secret:
    if IS_PRODUCTION:
        raise RuntimeError(
            "SECRET_KEY no está definida. En producción debe configurarse como "
            "variable de entorno (ver .env.example)."
        )
    _secret = "piloto-evaluacion-comision-dev"
    print("[aviso] SECRET_KEY no definida: usando clave de desarrollo local.", file=sys.stderr)
app.config["SECRET_KEY"] = _secret

# --- Sesiones seguras -------------------------------------------------------
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=IS_PRODUCTION,  # en local (http) debe quedar en False
    SESSION_REFRESH_EACH_REQUEST=True,
    PERMANENT_SESSION_LIFETIME=timedelta(hours=int(os.environ.get("SESSION_HOURS", "8"))),
    MAX_CONTENT_LENGTH=int(os.environ.get("MAX_UPLOAD_MB", "64")) * 1024 * 1024,
)

# Render sirve la aplicación detrás de un proxy TLS: sin esto Flask no reconoce
# que la conexión original era https y las cookies seguras fallan.
if IS_PRODUCTION:
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)


@app.after_request
def secure_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    return response


def safe_next(destino):
    """Evita redirecciones abiertas usando el parámetro ?next=."""
    if not destino:
        return None
    partes = urlparse(destino)
    if partes.scheme or partes.netloc or not destino.startswith("/"):
        return None
    return destino

LEVELS = {
    0: "Insuficiente",
    1: "Condicional",
    2: "Aceptable",
    3: "Bueno",
    4: "Sobresaliente",
}

ADMIN_USER_ROLES = ("admin", "evaluador")
ROLE_LABELS = {
    "admin": "Administrador",
    "evaluador": "Evaluador/a de comisión",
}

RUBRIC = [
    (4, "Sobresaliente", "Supera lo esperado con aportes, mejoras o resultados verificables adicionales.", "3,70 - 4,00"),
    (3, "Bueno", "Cumple plenamente lo esperado para jerarquía, jornada, área y CDA.", "2,80 - 3,69"),
    (2, "Aceptable", "Cumple el mínimo reconocible con debilidades que requieren mejora.", "2,00 - 2,79"),
    (1, "Condicional", "Cumplimiento parcial o irregular con brechas relevantes.", "1,50 - 1,99"),
    (0, "Insuficiente", "No permite reconocer cumplimiento mínimo o carece de respaldo suficiente.", "0,00 - 1,49"),
]

GUIDES = {
    "Docencia": "Revise carga académica, programas, evaluación, material docente, dirección de tesis y coherencia con la jerarquía.",
    "Investigación y Desarrollo": "Revise proyectos, publicaciones, productos verificables, rol declarado y consistencia con autonomía esperada.",
    "Asistencia Técnica": "Revise propuesta, contrato, informes, actas de entrega, rol del académico y vínculo con el área.",
    "Administración Académica": "Revise resoluciones, actas, encargos, comisiones, responsabilidades directivas y continuidad de la gestión.",
    "Extensión - VIME": "Revise programas, certificados, convenios, proyectos VIME, participación pública e impacto externo.",
    "Educación Continua - VIME": "Use la guía de Extensión / VIME para diplomados, cursos, talleres y actividades EDUCO.",
    "Perfeccionamiento": "Revise plan de formación, certificados, constancias, tutorías, pasantías o cursos de actualización.",
}

REQUIREMENT_TEXT = [
    {
        "title": "Artículo 25",
        "text": "Para académicos incorporados desde 2007, el cambio de jerarquía, acceso a planta o asimilación requiere haberse sometido a evaluación y calificación de desempeño académico y estar clasificado en una categoría igual o superior a Bueno.",
    },
    {
        "title": "Artículo 26",
        "text": "Las o los académicos que se hayan incorporado a la Universidad a partir del 2007 deberán, con el fin de acceder a la categoría aceptable definida en el artículo 13 de la Resolución N° 5949 de 2009, cumplir con al menos una docencia de calidad, en cantidad establecida por los lineamientos institucionales (Resolución N° 10301 del 29 de octubre de 2010) y con alguno de los siguientes requisitos de investigación:",
        "bullets": [
            "Tener publicaciones que cumplan con los estándares de la ley de aseguramiento de la calidad para programas de doctorado o especialidad médica en su área en los períodos que dichas orientaciones establecen.",
            "Tener a lo menos una publicación promedio anual por académico/a, en revista indexada WOS o Scopus, durante el respectivo período de calificación y evaluación.",
            "Se considerará la equivalencia de una publicación indexada a una patente de invención otorgada, o un spin off o start up constituida y aprobada institucionalmente.",
            "Se considerará en equivalencia a los productos indicados en los puntos b y c a otros productos evaluables de acuerdo a estándares externos de la institución, tales como proyectos o contratos tecnológicos CORFO, proyectos CONICYT, FONDEF, ICM, Internacionales, FONIS, FIA, FIC, GORE y de Ministerios, en los cuales el académico participe en calidad de investigador principal o responsable.",
        ],
        "closing": "La Universidad dispondrá de los apoyos necesarios para incentivar el cumplimiento de estos estándares indicados anteriormente a aquellos académicos que lo requieran y lo soliciten.",
    },
    {
        "title": "Aplicación en este piloto",
        "text": "Si la comisión marca que el académico no cumple el requisito normativo, el resultado final se presenta automáticamente como Condicional y se conserva visible la nota que habría obtenido sin aplicar este requisito.",
    },
]


@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "LEVELS": LEVELS, "REQUIREMENT_TEXT": REQUIREMENT_TEXT, "ROLE_LABELS": ROLE_LABELS}


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    with get_connection() as db:
        return db.execute("SELECT * FROM usuarios WHERE id = ?", (user_id,)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)

    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = current_user()
            if not user or user["rol"] not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


def now():
    return datetime.now().isoformat(timespec="seconds")


def active_area_count(db, academico_id):
    return db.execute(
        """
        SELECT COUNT(*) AS total
        FROM areas_compromiso
        WHERE academico_id = ? AND (horas_comprometidas_anuales > 0 OR horas_realizadas_anuales > 0 OR horas_semana > 0 OR horas_anio > 0 OR peso > 0)
        """,
        (academico_id,),
    ).fetchone()["total"]


def assignment_progress(db, asignacion_id, academico_id):
    total = active_area_count(db, academico_id)
    done = db.execute(
        """
        SELECT COUNT(*) AS total
        FROM evaluaciones_individuales ei
        JOIN areas_compromiso ac ON ac.id = ei.area_id
        WHERE ei.asignacion_id = ?
          AND ei.estado = 'enviada'
          AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
        """,
        (asignacion_id,),
    ).fetchone()["total"]
    return {"done": done, "total": total, "pct": round((done / total) * 100) if total else 0}


def get_assignment_for_user(db, codigo, user_id):
    return db.execute(
        """
        SELECT ae.*, a.codigo, a.codigo_base, a.nombre, a.jerarquia, a.jornada, a.departamento, a.periodo,
               a.anio_evaluacion, a.persona_id, a.source_excel,
               a.anio_ingreso, a.requisito_art25_cumple, a.requisito_art25_observacion,
               a.requisito_art25_actualizado_en
        FROM asignaciones_evaluacion ae
        JOIN academicos a ON a.id = ae.academico_id
        WHERE a.codigo = ? AND ae.evaluador_id = ?
        """,
        (codigo, user_id),
    ).fetchone()


def save_area_evaluation(db, asignacion_id, area_id, form, estado):
    level = form.get("nivel")
    nivel = int(level) if level not in (None, "") else None
    db.execute(
        """
        INSERT INTO evaluaciones_individuales
        (asignacion_id, area_id, nivel, evidencia_predominante, confianza, fundamento,
         fortalezas, aspectos_mejorar, recomendacion, estado, actualizado_en, enviado_en)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(asignacion_id, area_id) DO UPDATE SET
          nivel = excluded.nivel,
          evidencia_predominante = excluded.evidencia_predominante,
          confianza = excluded.confianza,
          fundamento = excluded.fundamento,
          fortalezas = excluded.fortalezas,
          aspectos_mejorar = excluded.aspectos_mejorar,
          recomendacion = excluded.recomendacion,
          estado = excluded.estado,
          actualizado_en = excluded.actualizado_en,
          enviado_en = COALESCE(excluded.enviado_en, evaluaciones_individuales.enviado_en)
        """,
        (
            asignacion_id,
            area_id,
            nivel,
            form.get("evidencia_predominante"),
            form.get("confianza"),
            form.get("fundamento", "").strip(),
            form.get("fortalezas", "").strip(),
            form.get("aspectos_mejorar", "").strip(),
            form.get("recomendacion", "").strip(),
            estado,
            now(),
            now() if estado == "enviada" else None,
        ),
    )


def validate_complete_assignment(db, asignacion_id, academico_id):
    rows = db.execute(
        """
        SELECT ac.nombre, ei.nivel, ei.fundamento
        FROM areas_compromiso ac
        LEFT JOIN evaluaciones_individuales ei
          ON ei.area_id = ac.id AND ei.asignacion_id = ?
        WHERE ac.academico_id = ?
          AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
        """,
        (asignacion_id, academico_id),
    ).fetchall()
    missing = [r["nombre"] for r in rows if r["nivel"] is None or not (r["fundamento"] or "").strip()]
    return missing


def category(score):
    if score >= 3.70:
        return "Sobresaliente"
    if score >= 2.80:
        return "Bueno"
    if score >= 2.00:
        return "Aceptable"
    if score >= 1.50:
        return "Condicional"
    return "Insuficiente"


def apply_normative_requirement(score, cumple):
    if cumple == 0:
        return {
            "score": 1.99,
            "category": "Condicional",
            "raw_score": score,
            "raw_category": category(score),
            "forced": True,
        }
    return {
        "score": score,
        "category": category(score),
        "raw_score": score,
        "raw_category": category(score),
        "forced": False,
    }


@app.route("/")
def index():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    if user["rol"] == "evaluador":
        return redirect(url_for("evaluador_panel"))
    return redirect(url_for("admin_panel"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_connection() as db:
            user = db.execute("SELECT * FROM usuarios WHERE email = ? AND activo = 1", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.permanent = True
            session["user_id"] = user["id"]
            log_event(user["id"], "login", "usuarios", user["id"], f"Ingreso de {email}")
            return redirect(safe_next(request.args.get("next")) or url_for("index"))
        flash("Credenciales inválidas.", "bad")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    uid = session.get("user_id")
    log_event(uid, "logout", "usuarios", uid, "Cierre de sesión")
    session.clear()
    return redirect(url_for("login"))


@app.route("/evaluador")
@login_required
@role_required("evaluador")
def evaluador_panel():
    user = current_user()
    with get_connection() as db:
        rows = db.execute(
            """
            SELECT ae.id AS asignacion_id, a.*,
                   p.nombre AS persona_nombre, p.codigo AS persona_codigo
            FROM asignaciones_evaluacion ae
            JOIN academicos a ON a.id = ae.academico_id
            LEFT JOIN personas_academicas p ON p.id = a.persona_id
            WHERE ae.evaluador_id = ?
            ORDER BY COALESCE(p.codigo, a.codigo_base, a.codigo), COALESCE(a.anio_evaluacion, CAST(a.periodo AS INTEGER)), a.codigo
            """,
            (user["id"],),
        ).fetchall()
        items = []
        for row in rows:
            progress = assignment_progress(db, row["asignacion_id"], row["id"])
            items.append({"academico": row, "progress": progress})
    return render_template("evaluador_panel.html", items=items)


@app.route("/evaluador/evaluar/<codigo>", methods=["GET", "POST"])
@login_required
@role_required("evaluador")
def evaluar(codigo):
    user = current_user()
    with get_connection() as db:
        asignacion = get_assignment_for_user(db, codigo, user["id"])
        if not asignacion:
            abort(404)
        areas = db.execute(
            """
            SELECT * FROM areas_compromiso
            WHERE academico_id = ?
              AND (horas_comprometidas_anuales > 0 OR horas_realizadas_anuales > 0
                   OR horas_semana > 0 OR horas_anio > 0 OR peso > 0)
            ORDER BY id
            """,
            (asignacion["academico_id"],),
        ).fetchall()
        if not areas:
            flash("Esta evaluación anual no tiene áreas activas declaradas en el Excel.", "warn")
            return redirect(url_for("evaluador_panel"))

        requested_area = request.args.get("area_id") or request.form.get("area_id")
        try:
            requested_area_id = int(requested_area) if requested_area else areas[0]["id"]
        except (TypeError, ValueError):
            requested_area_id = areas[0]["id"]
        area = next((a for a in areas if a["id"] == requested_area_id), areas[0])
        existing = db.execute(
            "SELECT * FROM evaluaciones_individuales WHERE asignacion_id = ? AND area_id = ?",
            (asignacion["id"], area["id"]),
        ).fetchone()

        if request.method == "POST":
            action = request.form.get("action")
            if action == "requirement":
                if request.form.get("requisito_art25_cumple") not in ("si", "no"):
                    flash("Debes indicar si cumple o no cumple el requisito normativo.", "bad")
                    return redirect(url_for("evaluar", codigo=codigo, area_id=area["id"]))
                cumple = 1 if request.form.get("requisito_art25_cumple") == "si" else 0
                db.execute(
                    """
                    UPDATE academicos
                    SET requisito_art25_cumple = ?, requisito_art25_observacion = ?,
                        requisito_art25_actualizado_por = ?, requisito_art25_actualizado_en = ?
                    WHERE id = ?
                    """,
                    (cumple, request.form.get("requisito_art25_observacion", "").strip(), user["id"], now(), asignacion["academico_id"]),
                )
                db.commit()
                log_event(user["id"], "guardar requisito normativo", "academicos", asignacion["academico_id"], f"{codigo}: {'cumple' if cumple else 'no cumple'}")
                flash("Requisito normativo actualizado.", "ok")
                return redirect(url_for("evaluar", codigo=codigo, area_id=area["id"]))

            if existing and existing["estado"] == "enviada":
                flash("Esta evaluación ya fue enviada y está bloqueada.", "bad")
                return redirect(url_for("evaluar", codigo=codigo, area_id=area["id"]))

            if action == "submit":
                save_area_evaluation(db, asignacion["id"], area["id"], request.form, "borrador")
                missing = validate_complete_assignment(db, asignacion["id"], asignacion["academico_id"])
                if missing:
                    db.commit()
                    flash("No se puede enviar. Faltan nivel y fundamento en: " + ", ".join(missing), "bad")
                    return redirect(url_for("evaluar", codigo=codigo, area_id=area["id"]))
                db.execute(
                    """
                    UPDATE evaluaciones_individuales
                    SET estado = 'enviada', enviado_en = COALESCE(enviado_en, ?), actualizado_en = ?
                    WHERE asignacion_id = ?
                    """,
                    (now(), now(), asignacion["id"]),
                )
                db.execute("UPDATE asignaciones_evaluacion SET estado = 'enviada' WHERE id = ?", (asignacion["id"],))
                db.commit()
                log_event(user["id"], "enviar evaluación", "asignaciones_evaluacion", asignacion["id"], codigo)
                flash("Evaluación enviada. La edición quedó bloqueada.", "ok")
                return redirect(url_for("evaluador_panel"))

            save_area_evaluation(db, asignacion["id"], area["id"], request.form, "borrador")
            db.execute("UPDATE asignaciones_evaluacion SET estado = 'borrador' WHERE id = ?", (asignacion["id"],))
            db.commit()
            log_event(user["id"], "guardar borrador", "areas_compromiso", area["id"], f"{codigo} - {area['nombre']}")
            flash("Borrador guardado.", "ok")
            return redirect(url_for("evaluar", codigo=codigo, area_id=area["id"]))

        activity_rows = db.execute(
            "SELECT * FROM actividades_comprometidas WHERE area_id = ? ORDER BY source_row IS NULL, source_row, id",
            (area["id"],),
        ).fetchall()
        activity_ids = [r["id"] for r in activity_rows]
        evidence_by_activity = defaultdict(list)
        if activity_ids:
            placeholders = ",".join("?" for _ in activity_ids)
            for evd in db.execute(
                f"SELECT * FROM evidencias WHERE actividad_id IN ({placeholders}) ORDER BY titulo",
                activity_ids,
            ).fetchall():
                evidence_by_activity[evd["actividad_id"]].append(evd)
        actividades = [{"row": r, "evidencias": evidence_by_activity.get(r["id"], [])} for r in activity_rows]
        area_evidences = db.execute(
            "SELECT * FROM evidencias WHERE evaluacion_id=? AND area_id=? AND actividad_id IS NULL ORDER BY titulo",
            (asignacion["academico_id"], area["id"]),
        ).fetchall()
        evaluation_evidences = db.execute(
            "SELECT * FROM evidencias WHERE evaluacion_id=? AND area_id IS NULL ORDER BY titulo",
            (asignacion["academico_id"],),
        ).fetchall()

        evaluations = {
            r["area_id"]: r
            for r in db.execute(
                "SELECT * FROM evaluaciones_individuales WHERE asignacion_id = ?",
                (asignacion["id"],),
            ).fetchall()
        }
        progress = assignment_progress(db, asignacion["id"], asignacion["academico_id"])
        total_area_weight = sum((a["peso"] or 0) for a in areas) or 1
        area_summary = [
            {"area": a, "normalized_weight": ((a["peso"] or 0) / total_area_weight) * 100}
            for a in areas
        ]
    return render_template(
        "evaluar.html",
        asignacion=asignacion,
        areas=areas,
        area_summary=area_summary,
        area=area,
        actividades=actividades,
        area_evidences=area_evidences,
        evaluation_evidences=evaluation_evidences,
        current_eval=existing,
        evaluations=evaluations,
        progress=progress,
        guide=GUIDES.get(area["nombre"], GUIDES["Docencia"]),
        rubric=RUBRIC,
    )


@app.route("/director")
@login_required
@role_required("evaluador")
def director_panel():
    # Alias histórico: en este piloto el director ingresa como evaluador.
    return redirect(url_for("deliberacion_panel"))


@app.route("/deliberacion")
@login_required
@role_required("evaluador")
def deliberacion_panel():
    with get_connection() as db:
        rows = db.execute(
            """
            WITH metrics AS (
              SELECT a.id, a.codigo, a.jerarquia, a.jornada, a.anio_ingreso, a.requisito_art25_cumple,
                (
                  SELECT COUNT(*)
                  FROM areas_compromiso ac
                  WHERE ac.academico_id = a.id
                    AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
                ) AS areas_activas,
                (
                  SELECT COUNT(*)
                  FROM asignaciones_evaluacion ae
                  WHERE ae.academico_id = a.id
                ) AS integrantes,
                (
                  SELECT COUNT(*)
                  FROM evaluaciones_individuales ei
                  JOIN asignaciones_evaluacion ae ON ae.id = ei.asignacion_id
                  JOIN areas_compromiso ac ON ac.id = ei.area_id
                  WHERE ae.academico_id = a.id
                    AND ei.estado = 'enviada'
                    AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
                ) AS evaluaciones_enviadas,
                (
                  SELECT COUNT(*)
                  FROM evaluacion_final_comision ef
                  JOIN areas_compromiso ac ON ac.id = ef.area_id
                  WHERE ac.academico_id = a.id
                    AND ef.nivel_final IS NOT NULL
                    AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
                ) AS acuerdos_finales,
                (
                  SELECT SUM(ac.peso)
                  FROM areas_compromiso ac
                  WHERE ac.academico_id = a.id
                    AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
                ) AS peso_total,
                (
                  SELECT SUM(ef.nivel_final * ac.peso)
                  FROM evaluacion_final_comision ef
                  JOIN areas_compromiso ac ON ac.id = ef.area_id
                  WHERE ac.academico_id = a.id
                    AND ef.nivel_final IS NOT NULL
                    AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
                ) AS suma_ponderada
              FROM academicos a
            )
            SELECT *,
              CASE
                WHEN acuerdos_finales = areas_activas AND peso_total > 0
                THEN suma_ponderada / peso_total
                ELSE NULL
              END AS calificacion_final
            FROM metrics
            WHERE areas_activas > 0
              AND integrantes > 0
              AND evaluaciones_enviadas = areas_activas * integrantes
            ORDER BY codigo
            """
        ).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        if row["calificacion_final"] is not None:
            applied = apply_normative_requirement(row["calificacion_final"], row["requisito_art25_cumple"])
            item["calificacion_sin_requisito"] = applied["raw_score"]
            item["categoria_sin_requisito"] = applied["raw_category"]
            item["calificacion_final_aplicada"] = applied["score"]
            item["categoria_final"] = applied["category"]
            item["forzada_por_requisito"] = applied["forced"]
        else:
            item["calificacion_sin_requisito"] = None
            item["categoria_sin_requisito"] = None
            item["calificacion_final_aplicada"] = None
            item["categoria_final"] = None
            item["forzada_por_requisito"] = False
        items.append(item)
    return render_template("deliberacion_panel.html", items=items)


@app.route("/deliberacion/<codigo>", methods=["GET", "POST"])
@login_required
@role_required("evaluador")
def deliberacion_detalle(codigo):
    user = current_user()
    with get_connection() as db:
        academico = db.execute("SELECT * FROM academicos WHERE codigo = ?", (codigo,)).fetchone()
        if not academico:
            abort(404)

        if request.method == "POST":
            area_id = int(request.form["area_id"])
            if not request.form.get("fundamento_final", "").strip():
                flash("El fundamento final es obligatorio.", "bad")
                return redirect(url_for("deliberacion_detalle", codigo=codigo) + f"#area-{area_id}")
            db.execute(
                """
                INSERT INTO evaluacion_final_comision
                (area_id, nivel_final, fundamento_final, fortalezas_final, aspectos_mejorar_final,
                 recomendacion_final, comentario_final, consenso, usuario_id, actualizado_en)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(area_id) DO UPDATE SET
                  nivel_final = excluded.nivel_final,
                  fundamento_final = excluded.fundamento_final,
                  fortalezas_final = excluded.fortalezas_final,
                  aspectos_mejorar_final = excluded.aspectos_mejorar_final,
                  recomendacion_final = excluded.recomendacion_final,
                  comentario_final = excluded.comentario_final,
                  consenso = excluded.consenso,
                  usuario_id = excluded.usuario_id,
                  actualizado_en = excluded.actualizado_en
                """,
                (
                    area_id,
                    int(request.form["nivel_final"]),
                    request.form["fundamento_final"].strip(),
                    request.form.get("fortalezas_final", "").strip(),
                    request.form.get("aspectos_mejorar_final", "").strip(),
                    request.form.get("recomendacion_final", "").strip(),
                    request.form.get("comentario_final", "").strip(),
                    1 if request.form.get("consenso") == "si" else 0,
                    user["id"],
                    now(),
                ),
            )
            db.commit()
            log_event(user["id"], "guardar nota final", "areas_compromiso", area_id, f"{codigo}")
            flash("Nota final guardada.", "ok")
            return redirect(url_for("deliberacion_detalle", codigo=codigo) + f"#area-{area_id}")

        areas = db.execute(
            """
            SELECT ac.*, ef.nivel_final, ef.fundamento_final, ef.fortalezas_final,
                   ef.aspectos_mejorar_final, ef.recomendacion_final, ef.comentario_final,
                   ef.consenso, ef.actualizado_en
            FROM areas_compromiso ac
            LEFT JOIN evaluacion_final_comision ef ON ef.area_id = ac.id
            WHERE ac.academico_id = ?
              AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
            ORDER BY ac.id
            """,
            (academico["id"],),
        ).fetchall()
        individuales = db.execute(
            """
            SELECT ac.id AS area_id, u.nombre AS evaluador, u.rol, u.email,
                   ei.nivel, ei.evidencia_predominante, ei.confianza, ei.fundamento,
                   ei.fortalezas, ei.aspectos_mejorar, ei.recomendacion, ei.estado
            FROM areas_compromiso ac
            JOIN asignaciones_evaluacion ae ON ae.academico_id = ac.academico_id
            JOIN usuarios u ON u.id = ae.evaluador_id
            LEFT JOIN evaluaciones_individuales ei
              ON ei.asignacion_id = ae.id AND ei.area_id = ac.id
            WHERE ac.academico_id = ?
              AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
            ORDER BY ac.id, u.email
            """,
            (academico["id"],),
        ).fetchall()

    por_area = defaultdict(list)
    for row in individuales:
        por_area[row["area_id"]].append(row)
    area_cards = []
    for area in areas:
        rows = por_area[area["id"]]
        levels = [r["nivel"] for r in rows if r["estado"] == "enviada" and r["nivel"] is not None]
        area_cards.append(
            {
                "area": area,
                "individuales": rows,
                "diff": (max(levels) - min(levels)) if levels else None,
                "requires": (max(levels) - min(levels) >= 2) if levels else False,
            }
        )
    total_weight = sum((card["area"]["peso"] or 0) for card in area_cards) or 1
    final_complete = bool(area_cards) and all(card["area"]["nivel_final"] is not None for card in area_cards)
    final_score_raw = sum(((card["area"]["nivel_final"] or 0) * (card["area"]["peso"] or 0)) / total_weight for card in area_cards)
    applied_result = apply_normative_requirement(final_score_raw, academico["requisito_art25_cumple"]) if final_complete else None
    return render_template(
        "deliberacion_detalle.html",
        academico=academico,
        area_cards=area_cards,
        final_score=applied_result["score"] if applied_result else final_score_raw,
        final_score_raw=final_score_raw,
        final_complete=final_complete,
        final_category=applied_result["category"] if applied_result else None,
        forced_by_requirement=applied_result["forced"] if applied_result else False,
        levels=LEVELS,
    )


@app.route("/deliberacion/acuerdo/<int:area_id>", methods=["GET", "POST"])
@login_required
@role_required("evaluador")
def acuerdo(area_id):
    user = current_user()
    with get_connection() as db:
        area = db.execute(
            """
            SELECT ac.*, a.codigo, a.jerarquia, a.jornada
            FROM areas_compromiso ac
            JOIN academicos a ON a.id = ac.academico_id
            WHERE ac.id = ?
            """,
            (area_id,),
        ).fetchone()
        if not area:
            abort(404)
        if request.method == "POST":
            if not request.form.get("fundamento_final", "").strip():
                flash("El fundamento final es obligatorio.", "bad")
                return redirect(url_for("acuerdo", area_id=area_id))
            db.execute(
                """
                INSERT INTO evaluacion_final_comision
                (area_id, nivel_final, fundamento_final, recomendacion_final, consenso, usuario_id, actualizado_en)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(area_id) DO UPDATE SET
                  nivel_final = excluded.nivel_final,
                  fundamento_final = excluded.fundamento_final,
                  recomendacion_final = excluded.recomendacion_final,
                  consenso = excluded.consenso,
                  usuario_id = excluded.usuario_id,
                  actualizado_en = excluded.actualizado_en
                """,
                (
                    area_id,
                    int(request.form["nivel_final"]),
                    request.form["fundamento_final"].strip(),
                    request.form.get("recomendacion_final", "").strip(),
                    1 if request.form.get("consenso") == "si" else 0,
                    user["id"],
                    now(),
                ),
            )
            db.commit()
            log_event(user["id"], "guardar acuerdo final", "areas_compromiso", area_id, f"{area['codigo']} - {area['nombre']}")
            flash("Acuerdo final guardado.", "ok")
            return redirect(url_for("deliberacion_detalle", codigo=area["codigo"]) + f"#area-{area_id}")

        individuales = db.execute(
            """
            SELECT u.nombre AS evaluador, ei.*
            FROM asignaciones_evaluacion ae
            JOIN usuarios u ON u.id = ae.evaluador_id
            LEFT JOIN evaluaciones_individuales ei ON ei.asignacion_id = ae.id AND ei.area_id = ?
            WHERE ae.academico_id = ?
            ORDER BY u.email
            """,
            (area_id, area["academico_id"]),
        ).fetchall()
        final = db.execute("SELECT * FROM evaluacion_final_comision WHERE area_id = ?", (area_id,)).fetchone()
    return render_template("acuerdo.html", area=area, individuales=individuales, final=final, levels=LEVELS)


@app.route("/informe/<codigo>")
@login_required
@role_required("evaluador", "admin")
def informe(codigo):
    user = current_user()
    with get_connection() as db:
        academico = db.execute("SELECT * FROM academicos WHERE codigo = ?", (codigo,)).fetchone()
        if not academico:
            abort(404)
        rows = db.execute(
            """
            SELECT ac.*, ef.nivel_final, ef.fundamento_final, ef.fortalezas_final,
                   ef.aspectos_mejorar_final, ef.recomendacion_final, ef.comentario_final, ef.consenso,
                   GROUP_CONCAT(NULLIF(ei.fortalezas, ''), ' | ') AS fortalezas,
                   GROUP_CONCAT(NULLIF(ei.aspectos_mejorar, ''), ' | ') AS aspectos_mejorar
            FROM areas_compromiso ac
            LEFT JOIN evaluacion_final_comision ef ON ef.area_id = ac.id
            LEFT JOIN asignaciones_evaluacion ae ON ae.academico_id = ac.academico_id
            LEFT JOIN evaluaciones_individuales ei
              ON ei.asignacion_id = ae.id AND ei.area_id = ac.id AND ei.estado = 'enviada'
            WHERE ac.academico_id = ? AND (ac.horas_comprometidas_anuales > 0 OR ac.horas_realizadas_anuales > 0 OR ac.horas_semana > 0 OR ac.horas_anio > 0 OR ac.peso > 0)
            GROUP BY ac.id
            ORDER BY ac.id
            """,
            (academico["id"],),
        ).fetchall()
        firmantes = db.execute(
            """
            SELECT nombre, email, rol
            FROM usuarios
            WHERE rol = 'evaluador'
            ORDER BY email
            """
        ).fetchall()
        total_weight = sum((r["peso"] or 0) for r in rows) or 1
        summary_rows = []
        for row in rows:
            normalized_weight = ((row["peso"] or 0) / total_weight) * 100
            contribution = ((row["nivel_final"] or 0) * normalized_weight) / 100
            summary_rows.append(
                {
                    "row": row,
                    "normalized_weight": normalized_weight,
                    "contribution": contribution,
                }
            )
        score = sum(item["contribution"] for item in summary_rows)
        completed = bool(rows) and all(r["nivel_final"] is not None for r in rows)
        applied_result = apply_normative_requirement(score, academico["requisito_art25_cumple"]) if completed else None
        log_event(user["id"], "generar informe", "academicos", academico["id"], codigo)
    return render_template(
        "informe.html",
        academico=academico,
        rows=rows,
        summary_rows=summary_rows,
        total_weight=total_weight,
        score=applied_result["score"] if applied_result else score,
        raw_score=score,
        completed=completed,
        forced_by_requirement=applied_result["forced"] if applied_result else False,
        firmantes=firmantes,
        category=applied_result["category"] if applied_result else category(score),
        raw_category=applied_result["raw_category"] if applied_result else category(score),
        levels=LEVELS,
    )


@app.route("/informe/<codigo>/notificar", methods=["POST"])
@login_required
@role_required("evaluador", "admin")
def notificar_academico(codigo):
    user = current_user()
    with get_connection() as db:
        academico = db.execute("SELECT * FROM academicos WHERE codigo = ?", (codigo,)).fetchone()
        if not academico:
            abort(404)
        log_event(
            user["id"],
            "notificar academico",
            "academicos",
            academico["id"],
            f"Notificacion simulada de informe final {codigo}",
        )
    flash("Notificacion simulada enviada al academico. En el piloto, aqui se conectaria el portal del evaluado.", "ok")
    return redirect(url_for("informe", codigo=codigo))


@app.route("/admin")
@login_required
@role_required("admin")
def admin_panel():
    with get_connection() as db:
        usuarios = db.execute(
            """
            SELECT u.id, u.email, u.nombre, u.rol, u.activo,
                   COUNT(ae.id) AS asignaciones_total
            FROM usuarios u
            LEFT JOIN asignaciones_evaluacion ae ON ae.evaluador_id = u.id
            GROUP BY u.id, u.email, u.nombre, u.rol, u.activo
            ORDER BY u.rol, u.email
            """
        ).fetchall()
        total_personas = db.execute("SELECT COUNT(*) AS n FROM personas_academicas").fetchone()["n"]
        total_academicos = db.execute("SELECT COUNT(*) AS n FROM academicos").fetchone()["n"]
        pendientes_evidencia = db.execute(
            "SELECT COUNT(*) AS n FROM evidencias WHERE estado_asociacion='pendiente'"
        ).fetchone()["n"]
        evaluaciones = db.execute(
            """
            SELECT a.id, a.codigo, a.codigo_base, a.nombre, a.anio_evaluacion, a.jerarquia, a.jornada,
                   a.departamento, p.codigo AS persona_codigo, p.nombre AS persona_nombre,
                   (SELECT COUNT(*) FROM areas_compromiso ac
                    WHERE ac.academico_id=a.id AND
                          (ac.horas_comprometidas_anuales>0 OR ac.horas_realizadas_anuales>0
                           OR ac.horas_semana>0 OR ac.horas_anio>0 OR ac.peso>0)) AS areas_activas,
                   (SELECT COUNT(*) FROM actividades_comprometidas act
                    JOIN areas_compromiso ac2 ON ac2.id=act.area_id WHERE ac2.academico_id=a.id) AS actividades,
                   (SELECT COUNT(*) FROM asignaciones_evaluacion ae WHERE ae.academico_id=a.id) AS evaluadores
            FROM academicos a
            LEFT JOIN personas_academicas p ON p.id=a.persona_id
            ORDER BY COALESCE(p.codigo,a.codigo_base,a.codigo), COALESCE(a.anio_evaluacion,CAST(a.periodo AS INTEGER))
            """
        ).fetchall()
        importaciones = db.execute(
            "SELECT * FROM importaciones ORDER BY id DESC LIMIT 10"
        ).fetchall()
        bitacora = db.execute(
            """
            SELECT b.*, u.email
            FROM bitacora b
            LEFT JOIN usuarios u ON u.id = b.usuario_id
            ORDER BY b.id DESC
            LIMIT 100
            """
        ).fetchall()
        enviadas = db.execute(
            """
            SELECT ae.id AS asignacion_id, a.codigo, u.email,
                   COUNT(ei.id) AS areas_enviadas,
                   MAX(ei.enviado_en) AS enviado_en
            FROM asignaciones_evaluacion ae
            JOIN academicos a ON a.id = ae.academico_id
            JOIN usuarios u ON u.id = ae.evaluador_id
            JOIN evaluaciones_individuales ei ON ei.asignacion_id = ae.id
            WHERE ei.estado = 'enviada'
            GROUP BY ae.id, a.codigo, u.email
            ORDER BY a.codigo, u.email
            """
        ).fetchall()
    return render_template(
        "admin_panel.html",
        usuarios=usuarios, bitacora=bitacora, enviadas=enviadas, roles=ADMIN_USER_ROLES,
        total_academicos=total_academicos, total_personas=total_personas,
        pendientes_evidencia=pendientes_evidencia, evaluaciones=evaluaciones, importaciones=importaciones,
    )


@app.route("/admin/usuarios", methods=["POST"])
@login_required
@role_required("admin")
def crear_usuario():
    user = current_user()
    email = request.form.get("email", "").strip().lower()
    nombre = request.form.get("nombre", "").strip()
    rol = request.form.get("rol", "").strip()
    password = request.form.get("password", "")

    if not email or "@" not in email:
        flash("Debes ingresar un correo válido.", "bad")
        return redirect(url_for("admin_panel"))
    if not nombre:
        flash("Debes ingresar el nombre del usuario.", "bad")
        return redirect(url_for("admin_panel"))
    if rol not in ADMIN_USER_ROLES:
        flash("Rol no válido.", "bad")
        return redirect(url_for("admin_panel"))
    if len(password) < 8:
        flash("La contraseña debe tener al menos 8 caracteres.", "bad")
        return redirect(url_for("admin_panel"))

    with get_connection() as db:
        existe = db.execute("SELECT id FROM usuarios WHERE email = ?", (email,)).fetchone()
        if existe:
            flash("Ya existe un usuario con ese correo. Usa la opción de restablecer contraseña si corresponde.", "bad")
            return redirect(url_for("admin_panel"))

        cur = db.execute(
            """
            INSERT INTO usuarios (email, nombre, password_hash, rol, activo, creado_en)
            VALUES (?, ?, ?, ?, 1, ?)
            """,
            (email, nombre, generate_password_hash(password), rol, now()),
        )
        nuevo_id = cur.lastrowid

        asignados = 0
        if request.form.get("asignar_todos") == "1" and rol == "evaluador":
            academicos = db.execute("SELECT id FROM academicos").fetchall()
            for academico in academicos:
                db.execute(
                    """
                    INSERT OR IGNORE INTO asignaciones_evaluacion
                    (academico_id, evaluador_id, estado, creado_en)
                    VALUES (?, ?, 'pendiente', ?)
                    """,
                    (academico["id"], nuevo_id, now()),
                )
                asignados += 1

        db.commit()

    detalle = f"Creación de usuario {email} con rol {rol}"
    if asignados:
        detalle += f"; asignado a {asignados} académico(s)"
    log_event(user["id"], "crear usuario", "usuarios", nuevo_id, detalle)
    flash("Usuario creado correctamente.", "ok")
    return redirect(url_for("admin_panel"))


@app.route("/admin/usuarios/<int:usuario_id>/password", methods=["POST"])
@login_required
@role_required("admin")
def restablecer_password_usuario(usuario_id):
    user = current_user()
    password = request.form.get("password", "")
    if len(password) < 8:
        flash("La nueva contraseña debe tener al menos 8 caracteres.", "bad")
        return redirect(url_for("admin_panel"))

    with get_connection() as db:
        row = db.execute("SELECT email FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
        if not row:
            abort(404)
        db.execute(
            "UPDATE usuarios SET password_hash = ? WHERE id = ?",
            (generate_password_hash(password), usuario_id),
        )
        db.commit()

    log_event(user["id"], "restablecer contraseña", "usuarios", usuario_id, f"Contraseña restablecida para {row['email']}")
    flash("Contraseña restablecida correctamente.", "ok")
    return redirect(url_for("admin_panel"))


@app.route("/admin/usuarios/<int:usuario_id>/toggle", methods=["POST"])
@login_required
@role_required("admin")
def activar_desactivar_usuario(usuario_id):
    user = current_user()
    if usuario_id == user["id"]:
        flash("No puedes desactivar tu propio usuario administrador.", "bad")
        return redirect(url_for("admin_panel"))

    with get_connection() as db:
        row = db.execute("SELECT email, activo FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
        if not row:
            abort(404)
        nuevo_estado = 0 if row["activo"] else 1
        db.execute("UPDATE usuarios SET activo = ? WHERE id = ?", (nuevo_estado, usuario_id))
        db.commit()

    accion = "activar usuario" if nuevo_estado else "desactivar usuario"
    log_event(user["id"], accion, "usuarios", usuario_id, row["email"])
    flash("Estado del usuario actualizado.", "ok")
    return redirect(url_for("admin_panel"))


@app.route("/admin/usuarios/<int:usuario_id>/asignar-todos", methods=["POST"])
@login_required
@role_required("admin")
def asignar_todos_usuario(usuario_id):
    user = current_user()
    with get_connection() as db:
        row = db.execute("SELECT email, rol FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
        if not row:
            abort(404)
        if row["rol"] != "evaluador":
            flash("Solo los usuarios evaluadores pueden recibir asignaciones.", "bad")
            return redirect(url_for("admin_panel"))

        academicos = db.execute("SELECT id FROM academicos").fetchall()
        creadas = 0
        for academico in academicos:
            cur = db.execute(
                """
                INSERT OR IGNORE INTO asignaciones_evaluacion
                (academico_id, evaluador_id, estado, creado_en)
                VALUES (?, ?, 'pendiente', ?)
                """,
                (academico["id"], usuario_id, now()),
            )
            creadas += cur.rowcount
        db.commit()

    log_event(user["id"], "asignar casos", "usuarios", usuario_id, f"{creadas} asignación(es) nuevas para {row['email']}")
    flash(f"Asignaciones creadas: {creadas}.", "ok")
    return redirect(url_for("admin_panel"))


@app.route("/admin/reabrir/<int:evaluacion_id>", methods=["POST"])
@login_required
@role_required("admin")
def reabrir(evaluacion_id):
    user = current_user()
    with get_connection() as db:
        row = db.execute("SELECT * FROM evaluaciones_individuales WHERE id = ?", (evaluacion_id,)).fetchone()
        if not row:
            abort(404)
        db.execute(
            "UPDATE evaluaciones_individuales SET estado = 'borrador', enviado_en = NULL, actualizado_en = ? WHERE id = ?",
            (now(), evaluacion_id),
        )
        db.execute("UPDATE asignaciones_evaluacion SET estado = 'borrador' WHERE id = ?", (row["asignacion_id"],))
        db.commit()
    log_event(user["id"], "reabrir evaluación", "evaluaciones_individuales", evaluacion_id, "Reapertura por admin")
    flash("Evaluación reabierta.", "ok")
    return redirect(url_for("admin_panel"))


@app.route("/admin/reabrir-asignacion/<int:asignacion_id>", methods=["POST"])
@login_required
@role_required("admin")
def reabrir_asignacion(asignacion_id):
    user = current_user()
    with get_connection() as db:
        row = db.execute("SELECT * FROM asignaciones_evaluacion WHERE id = ?", (asignacion_id,)).fetchone()
        if not row:
            abort(404)
        db.execute(
            """
            UPDATE evaluaciones_individuales
            SET estado = 'borrador', enviado_en = NULL, actualizado_en = ?
            WHERE asignacion_id = ?
            """,
            (now(), asignacion_id),
        )
        db.execute("UPDATE asignaciones_evaluacion SET estado = 'borrador' WHERE id = ?", (asignacion_id,))
        db.commit()
    log_event(user["id"], "reabrir evaluación", "asignaciones_evaluacion", asignacion_id, "Reapertura completa por académico/evaluador")
    flash("Evaluación del académico reabierta para ese evaluador.", "ok")
    return redirect(url_for("admin_panel"))


def _nullable_float(value):
    if value is None or str(value).strip() == "":
        return None
    try:
        return float(str(value).replace(",", "."))
    except ValueError:
        raise ValueError(f"Valor numérico no válido: {value}")


def _store_manual_files(db, files, evaluation, area_id=None, activity_id=None, description=""):
    saved = 0
    target_dir = Path(UPLOAD_ROOT) / evaluation["codigo"] / "manual"
    target_dir.mkdir(parents=True, exist_ok=True)
    for uploaded in files:
        if not uploaded or not uploaded.filename:
            continue
        original = Path(uploaded.filename).name
        safe = secure_filename(original) or "evidencia"
        data = uploaded.read()
        digest = hashlib.sha256(data).hexdigest()[:12]
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        stored_name = f"{stamp}_{digest}_{safe}"
        target = target_dir / stored_name
        target.write_bytes(data)
        rel = target.relative_to(Path(UPLOAD_ROOT)).as_posix()
        mime = uploaded.mimetype or mimetypes.guess_type(original)[0] or "application/octet-stream"
        state = "actividad" if activity_id else "area" if area_id else "evaluacion"
        db.execute(
            """INSERT INTO evidencias
               (persona_id,evaluacion_id,anio,area_id,actividad_id,titulo,descripcion,nombre_original,
                nombre_guardado,ruta_relativa,extension,mime_type,tamano,fecha_carga,origen,estado_asociacion)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (evaluation["persona_id"], evaluation["id"], evaluation["anio_evaluacion"], area_id, activity_id,
             original, description, original, stored_name, rel, Path(original).suffix.lower(), mime, len(data),
             now(), "carga manual", state),
        )
        saved += 1
    return saved


@app.route("/admin/importar", methods=["POST"])
@login_required
@role_required("admin")
def admin_importar():
    user = current_user()
    uploaded = request.files.get("archivo_zip")
    if not uploaded or not uploaded.filename:
        flash("Selecciona un archivo ZIP con los Excel y evidencias.", "bad")
        return redirect(url_for("admin_panel"))
    if not uploaded.filename.lower().endswith(".zip"):
        flash("La importación integrada acepta un archivo .zip.", "bad")
        return redirect(url_for("admin_panel"))
    with tempfile.NamedTemporaryFile(prefix="evaluacion_", suffix=".zip", delete=False) as tmp:
        uploaded.save(tmp.name)
        tmp_path = tmp.name
    try:
        import_id, report = import_evidence_zip(tmp_path, usuario_id=user["id"], original_name=uploaded.filename)
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
    log_event(user["id"], "importar ZIP", "importaciones", import_id, uploaded.filename)
    if report.get("errors"):
        flash("La importación terminó con errores. Revisa el reporte.", "bad")
    else:
        flash(f"Importación completada: {len(report.get('years_detected', []))} evaluación(es) anual(es).", "ok")
    return redirect(url_for("admin_import_report", import_id=import_id))


@app.route("/admin/importaciones/<int:import_id>")
@login_required
@role_required("admin")
def admin_import_report(import_id):
    with get_connection() as db:
        row = db.execute("SELECT * FROM importaciones WHERE id=?", (import_id,)).fetchone()
        if not row:
            abort(404)
        report = json.loads(row["reporte_json"] or "{}")
    return render_template("import_report.html", row=row, report=report)


@app.route("/admin/evaluaciones/<int:evaluation_id>")
@login_required
@role_required("admin")
def admin_evaluacion(evaluation_id):
    with get_connection() as db:
        evaluation = db.execute(
            """SELECT a.*, p.nombre AS persona_nombre, p.codigo AS persona_codigo
               FROM academicos a LEFT JOIN personas_academicas p ON p.id=a.persona_id WHERE a.id=?""",
            (evaluation_id,),
        ).fetchone()
        if not evaluation:
            abort(404)
        areas = db.execute("SELECT * FROM areas_compromiso WHERE academico_id=? ORDER BY id", (evaluation_id,)).fetchall()
        area_ids = [a["id"] for a in areas]
        activities_by_area = defaultdict(list)
        evidences_by_activity = defaultdict(list)
        evidences_by_area = defaultdict(list)
        if area_ids:
            ph=",".join("?" for _ in area_ids)
            acts=db.execute(f"SELECT * FROM actividades_comprometidas WHERE area_id IN ({ph}) ORDER BY area_id, source_row IS NULL, source_row, id", area_ids).fetchall()
            for act in acts:
                activities_by_area[act["area_id"]].append(act)
            act_ids=[a["id"] for a in acts]
            if act_ids:
                ph2=",".join("?" for _ in act_ids)
                for ev in db.execute(f"SELECT * FROM evidencias WHERE actividad_id IN ({ph2}) ORDER BY titulo", act_ids).fetchall():
                    evidences_by_activity[ev["actividad_id"]].append(ev)
            for ev in db.execute(f"SELECT * FROM evidencias WHERE evaluacion_id=? AND actividad_id IS NULL AND area_id IN ({ph}) ORDER BY titulo", [evaluation_id,*area_ids]).fetchall():
                evidences_by_area[ev["area_id"]].append(ev)
        eval_evidence=db.execute("SELECT * FROM evidencias WHERE evaluacion_id=? AND area_id IS NULL ORDER BY titulo", (evaluation_id,)).fetchall()
        pending=db.execute("SELECT * FROM evidencias WHERE persona_id=? AND estado_asociacion='pendiente' ORDER BY titulo", (evaluation["persona_id"],)).fetchall() if evaluation["persona_id"] else []
        evaluadores=db.execute("SELECT id,nombre,email FROM usuarios WHERE rol='evaluador' AND activo=1 ORDER BY nombre,email").fetchall()
        assigned={r["evaluador_id"] for r in db.execute("SELECT evaluador_id FROM asignaciones_evaluacion WHERE academico_id=?", (evaluation_id,)).fetchall()}
    return render_template(
        "admin_evaluacion.html", evaluation=evaluation, areas=areas, activities_by_area=activities_by_area,
        evidences_by_activity=evidences_by_activity, evidences_by_area=evidences_by_area, eval_evidence=eval_evidence,
        pending=pending, evaluadores=evaluadores, assigned=assigned, activity_catalog=ACTIVITY_CATALOG, area_order=AREA_ORDER,
    )


@app.route("/admin/actividades/<int:activity_id>/actualizar", methods=["POST"])
@login_required
@role_required("admin")
def admin_actualizar_actividad(activity_id):
    user=current_user()
    fields=("s1_comp_hsemana","s1_comp_hsemestre","s1_real_hsemana","s1_real_hsemestre",
            "s2_comp_hsemana","s2_comp_hsemestre","s2_real_hsemana","s2_real_hsemestre")
    try:
        values=[_nullable_float(request.form.get(f)) for f in fields]
    except ValueError as exc:
        flash(str(exc), "bad")
        return redirect(request.referrer or url_for("admin_panel"))
    with get_connection() as db:
        row=db.execute("""SELECT act.id, ac.academico_id FROM actividades_comprometidas act
                          JOIN areas_compromiso ac ON ac.id=act.area_id WHERE act.id=?""", (activity_id,)).fetchone()
        if not row: abort(404)
        db.execute(
            """UPDATE actividades_comprometidas SET actividad=?, contexto=?,
               s1_comp_hsemana=?,s1_comp_hsemestre=?,s1_real_hsemana=?,s1_real_hsemestre=?,
               s2_comp_hsemana=?,s2_comp_hsemestre=?,s2_real_hsemana=?,s2_real_hsemestre=?,
               observacion=?, evidencia_textual=? WHERE id=?""",
            (request.form.get("actividad","").strip() or "Otras actividades", request.form.get("contexto","").strip(),
             *values, request.form.get("observacion","").strip(), request.form.get("evidencia_textual","").strip(), activity_id),
        )
        recalculate_evaluation(db, row["academico_id"])
        db.commit()
    log_event(user["id"], "editar actividad", "actividades_comprometidas", activity_id, "Horas/observación actualizadas")
    flash("Actividad actualizada y resumen recalculado.", "ok")
    return redirect(url_for("admin_evaluacion", evaluation_id=row["academico_id"]))


@app.route("/admin/areas/<int:area_id>/actividad", methods=["POST"])
@login_required
@role_required("admin")
def admin_crear_actividad(area_id):
    user=current_user()
    with get_connection() as db:
        area=db.execute("SELECT * FROM areas_compromiso WHERE id=?", (area_id,)).fetchone()
        if not area: abort(404)
        evaluation=db.execute("SELECT * FROM academicos WHERE id=?", (area["academico_id"],)).fetchone()
        activity=(request.form.get("actividad") or request.form.get("actividad_libre") or "").strip()
        if not activity:
            flash("Indica una actividad.", "bad")
            return redirect(url_for("admin_evaluacion", evaluation_id=area["academico_id"]))
        cur=db.execute("""INSERT INTO actividades_comprometidas
             (area_id,actividad,contexto,observacion,evidencia,evidencia_textual,anio) VALUES (?,?,?,?,?,?,?)""",
             (area_id,activity,request.form.get("contexto","").strip(),request.form.get("observacion","").strip(),"",
              request.form.get("evidencia_textual","").strip(),evaluation["anio_evaluacion"]))
        recalculate_evaluation(db, area["academico_id"]); db.commit()
    log_event(user["id"], "crear actividad", "actividades_comprometidas", cur.lastrowid, activity)
    flash("Actividad agregada. Puedes completar sus horas en la ficha.", "ok")
    return redirect(url_for("admin_evaluacion", evaluation_id=area["academico_id"]))


@app.route("/admin/actividades/<int:activity_id>/evidencias", methods=["POST"])
@login_required
@role_required("admin")
def admin_subir_evidencias_actividad(activity_id):
    user=current_user()
    with get_connection() as db:
        row=db.execute("""SELECT act.id,act.area_id,ac.academico_id FROM actividades_comprometidas act
                          JOIN areas_compromiso ac ON ac.id=act.area_id WHERE act.id=?""", (activity_id,)).fetchone()
        if not row: abort(404)
        evaluation=db.execute("SELECT * FROM academicos WHERE id=?", (row["academico_id"],)).fetchone()
        n=_store_manual_files(db, request.files.getlist("archivos"), evaluation, row["area_id"], activity_id, request.form.get("descripcion","").strip())
        db.commit()
    log_event(user["id"], "subir evidencias", "actividades_comprometidas", activity_id, f"{n} archivo(s)")
    flash(f"Se asociaron {n} archivo(s) a la actividad.", "ok" if n else "warn")
    return redirect(url_for("admin_evaluacion", evaluation_id=row["academico_id"]))


@app.route("/admin/evaluaciones/<int:evaluation_id>/evidencias", methods=["POST"])
@login_required
@role_required("admin")
def admin_subir_evidencias_evaluacion(evaluation_id):
    user=current_user()
    area_id=request.form.get("area_id", type=int)
    with get_connection() as db:
        evaluation=db.execute("SELECT * FROM academicos WHERE id=?", (evaluation_id,)).fetchone()
        if not evaluation: abort(404)
        if area_id and not db.execute("SELECT 1 FROM areas_compromiso WHERE id=? AND academico_id=?", (area_id,evaluation_id)).fetchone():
            abort(400)
        n=_store_manual_files(db, request.files.getlist("archivos"), evaluation, area_id, None, request.form.get("descripcion","").strip())
        db.commit()
    log_event(user["id"], "subir evidencias", "academicos", evaluation_id, f"{n} archivo(s)")
    flash(f"Se cargaron {n} archivo(s).", "ok" if n else "warn")
    return redirect(url_for("admin_evaluacion", evaluation_id=evaluation_id))


@app.route("/admin/evidencias/<int:evidence_id>/asociar", methods=["POST"])
@login_required
@role_required("admin")
def admin_asociar_evidencia(evidence_id):
    user=current_user()
    evaluation_id=request.form.get("evaluation_id", type=int)
    area_id=request.form.get("area_id", type=int)
    activity_id=request.form.get("activity_id", type=int)
    with get_connection() as db:
        ev=db.execute("SELECT * FROM evidencias WHERE id=?", (evidence_id,)).fetchone()
        if not ev: abort(404)
        if not evaluation_id:
            db.execute("UPDATE evidencias SET evaluacion_id=NULL,anio=NULL,area_id=NULL,actividad_id=NULL,estado_asociacion='pendiente' WHERE id=?", (evidence_id,))
        else:
            evaluation=db.execute("SELECT * FROM academicos WHERE id=?", (evaluation_id,)).fetchone()
            if not evaluation: abort(400)
            if area_id and not db.execute("SELECT 1 FROM areas_compromiso WHERE id=? AND academico_id=?", (area_id,evaluation_id)).fetchone(): abort(400)
            if activity_id and not db.execute("""SELECT 1 FROM actividades_comprometidas act JOIN areas_compromiso ac ON ac.id=act.area_id
                                                  WHERE act.id=? AND ac.academico_id=?""", (activity_id,evaluation_id)).fetchone(): abort(400)
            if activity_id:
                act=db.execute("SELECT area_id FROM actividades_comprometidas WHERE id=?", (activity_id,)).fetchone(); area_id=act["area_id"]
            state="actividad" if activity_id else "area" if area_id else "evaluacion"
            db.execute("UPDATE evidencias SET evaluacion_id=?,anio=?,area_id=?,actividad_id=?,estado_asociacion=? WHERE id=?",
                       (evaluation_id,evaluation["anio_evaluacion"],area_id,activity_id,state,evidence_id))
        db.commit()
    log_event(user["id"], "asociar evidencia", "evidencias", evidence_id, f"evaluacion={evaluation_id}; area={area_id}; actividad={activity_id}")
    flash("Asociación de evidencia actualizada.", "ok")
    return redirect(request.referrer or url_for("admin_panel"))


@app.route("/admin/evaluaciones/<int:evaluation_id>/asignar", methods=["POST"])
@login_required
@role_required("admin")
def admin_asignar_evaluador(evaluation_id):
    user=current_user(); evaluator_id=request.form.get("evaluador_id", type=int)
    with get_connection() as db:
        if not db.execute("SELECT 1 FROM academicos WHERE id=?", (evaluation_id,)).fetchone(): abort(404)
        ev=db.execute("SELECT * FROM usuarios WHERE id=? AND rol='evaluador' AND activo=1", (evaluator_id,)).fetchone()
        if not ev:
            flash("Selecciona un evaluador activo.", "bad"); return redirect(url_for("admin_evaluacion", evaluation_id=evaluation_id))
        cur=db.execute("INSERT OR IGNORE INTO asignaciones_evaluacion (academico_id,evaluador_id,estado,creado_en) VALUES (?,?,'pendiente',?)", (evaluation_id,evaluator_id,now())); db.commit()
    log_event(user["id"], "asignar evaluación", "academicos", evaluation_id, ev["email"])
    flash("Evaluador asignado." if cur.rowcount else "Ese evaluador ya estaba asignado.", "ok" if cur.rowcount else "warn")
    return redirect(url_for("admin_evaluacion", evaluation_id=evaluation_id))


@app.route("/evidencias/<int:evidence_id>")
@login_required
def abrir_evidencia(evidence_id):
    user=current_user()
    with get_connection() as db:
        ev=db.execute("SELECT * FROM evidencias WHERE id=?", (evidence_id,)).fetchone()
        if not ev: abort(404)
        allowed=user["rol"] == "admin"
        if not allowed and ev["evaluacion_id"]:
            allowed=bool(db.execute("SELECT 1 FROM asignaciones_evaluacion WHERE academico_id=? AND evaluador_id=?", (ev["evaluacion_id"],user["id"])).fetchone())
        if not allowed: abort(403)
    return send_from_directory(UPLOAD_ROOT, ev["ruta_relativa"], as_attachment=False, download_name=ev["nombre_original"])


@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="No tienes permisos para acceder a esta vista."), 403


@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="No encontré el recurso solicitado."), 404


# Arranque de la base: se ejecuta también bajo Gunicorn (que importa este módulo
# y nunca entra al bloque __main__). Es idempotente y no carga datos simulados.
_estado_bd = bootstrap_database()
print(f"[bd] {_estado_bd['db_path']} | {_estado_bd['mensaje']}", file=sys.stderr)


@app.route("/healthz")
def healthz():
    """Endpoint de verificación para Render."""
    try:
        with get_connection() as db:
            db.execute("SELECT 1").fetchone()
        return {"estado": "ok", "base": os.path.basename(DB_PATH)}, 200
    except Exception:
        return {"estado": "error"}, 500


if __name__ == "__main__":
    app.run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG", "0") == "1",
    )

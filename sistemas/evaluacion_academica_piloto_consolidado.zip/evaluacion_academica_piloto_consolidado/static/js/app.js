function updateEvidenceWarning() {
  const checked = document.querySelector('input[name="nivel"]:checked');
  const evidence = document.querySelector('#evidenceType');
  const alert = document.querySelector('#evidenceAlert');
  if (!checked || !evidence || !alert) return;
  const level = Number(checked.value);
  alert.classList.toggle('hidden', !(level >= 3 && evidence.value === 'Evidencia declarativa'));
}

document.addEventListener('change', (event) => {
  if (event.target.name === 'nivel' || event.target.id === 'evidenceType') updateEvidenceWarning();
});

document.addEventListener('click', (event) => {
  const row = event.target.closest('.click-row');
  if (row && !event.target.closest('a, button, input, select, textarea')) {
    window.location.href = row.dataset.href;
    return;
  }

  const button = event.target.closest('[data-tab]');
  if (!button) return;
  const id = button.dataset.tab;
  document.querySelectorAll('.panel-tabs button').forEach((item) => item.classList.remove('active'));
  button.classList.add('active');
  document.querySelectorAll('.pcontent').forEach((item) => item.classList.add('hidden'));
  const pane = document.querySelector(`#tab-${id}`);
  if (pane) pane.classList.remove('hidden');
});

updateEvidenceWarning();

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function levelNumber(label) {
  const match = String(label).match(/\d+/);
  return match ? Number(match[0]) : 0;
}

function renderFullManual() {
  const guidePane = document.querySelector('#tab-guide');
  const rubricPane = document.querySelector('#tab-rubric');
  if (!guidePane || !rubricPane || !window.MANUAL_GUIDES || !window.MANUAL_RUBRIC) return;

  const hierarchy = guidePane.dataset.hierarchy || 'Asistente';
  const areaName = guidePane.dataset.area || 'Docencia';
  const hKey = (window.HIER_TO_GUIDE || {})[hierarchy] || 'asistente';
  const aKeyBase = (window.AREA_TO_GUIDE || {})[areaName] || 'doc';
  const hierarchyGuide = window.MANUAL_GUIDES[hKey] || window.MANUAL_GUIDES.asistente;
  const aKey = hierarchyGuide.areas[aKeyBase] ? aKeyBase : (hierarchyGuide.areas.ext ? 'ext' : Object.keys(hierarchyGuide.areas)[0]);
  const areaGuide = hierarchyGuide.areas[aKey];

  const eduNote = areaName === 'Educación Continua - VIME'
    ? '<div class="manual-note">El manual no presenta una pestaña separada para Educación Continua - VIME; se muestra la guía de <b>Extensión / VIME</b>.</div>'
    : '';

  guidePane.innerHTML = `
    <div class="manual-block">
      <h3>Guía Orientadora · Anexos II y III</h3>
      ${hierarchyGuide.profile}
      <h4>Área seleccionada: ${escapeHtml(areaGuide.label)}</h4>
      ${eduNote}
      ${areaGuide.html}
      <div class="guide-note"><b>Nota general sobre las guías:</b> Las guías tienen carácter orientador y no taxativo. No agotan las actividades posibles ni impiden declarar otras justificadas y respaldadas. No sustituyen el juicio académico fundado de la comisión.</div>
    </div>`;

  const scale = [...window.MANUAL_RUBRIC.scale].sort((a, b) => Number(b.num) - Number(a.num));
  const rangeMap = {};
  scale.forEach((item) => { rangeMap[String(item.num)] = item; });
  const levels = [...window.MANUAL_RUBRIC.levels].sort((a, b) => levelNumber(b[0]) - levelNumber(a[0]));

  rubricPane.innerHTML = `
    <div class="manual-block">
      <h3>Rúbrica de evaluación · Anexo I</h3>
      <div class="guide-note">Rúbrica holística completa para apoyar el juicio académico fundado por área.</div>
      <table class="manual-table">
        <thead><tr><th>Nivel</th><th>Descripción holística del desempeño</th></tr></thead>
        <tbody>
          ${levels.map((row) => {
            const num = levelNumber(row[0]);
            const meta = rangeMap[String(num)] || {};
            return `<tr><td><b>${escapeHtml(row[0])}</b><br><span class="range-tag">${escapeHtml(meta.name || '')}</span> <span class="range-tag">${escapeHtml(meta.range || '')}</span></td><td>${escapeHtml(row[1])}</td></tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

renderFullManual();

function openModal(id) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}
function closeModal(modal) {
  if (!modal) return;
  modal.classList.remove('is-open');
  modal.setAttribute('aria-hidden', 'true');
  if (!document.querySelector('.modal-shell.is-open')) document.body.style.overflow = '';
}
document.addEventListener('click', (event) => {
  const opener = event.target.closest('[data-open-modal]');
  if (opener) { openModal(opener.dataset.openModal); return; }
  if (event.target.closest('[data-close-modal]')) { closeModal(event.target.closest('.modal-shell')); }
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') document.querySelectorAll('.modal-shell.is-open').forEach(closeModal);
});

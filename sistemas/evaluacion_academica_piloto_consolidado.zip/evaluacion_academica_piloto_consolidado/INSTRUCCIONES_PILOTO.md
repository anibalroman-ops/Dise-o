# Instrucciones breves del piloto consolidado

## 1. Ejecutar

```bash
pip install -r requirements.txt
python app.py
```

Antes del primer inicio, copie `.env.example` como `.env` y configure `SECRET_KEY`, `ADMIN_INITIAL_EMAIL` y `ADMIN_INITIAL_PASSWORD`.

## 2. Importar

Como administrador, use **Importar convenio y evidencias**. También puede ejecutar:

```bash
python importar_evidencias.py "ruta/al/archivo.zip"
```

El sistema crea una persona real y evaluaciones anuales separadas. Con el material de validación se obtuvieron:

- `A-001-2023`
- `A-001-2024`
- `A-001-2025`

## 3. Revisar antes de asignar evaluadores

Abra cada evaluación anual desde Administración y revise:
- resumen automático por área;
- actividades y horas semestrales;
- observaciones del Excel;
- evidencias asociadas automáticamente;
- evidencias pendientes de asociación.

Los archivos pendientes se dejan así intencionalmente cuando la asociación no es suficientemente segura.

## 4. Evaluar

El evaluador verá cada año como un caso independiente. La vista prioriza horas realizadas, evidencias por actividad y muestra la guía orientadora y la rúbrica completas mediante botones/modales.

## Advertencia del Excel

En los tres Excel revisados, Educación Continua reutiliza la validación de actividades de Docencia. Esa lista no se hereda: el área queda con catálogo abierto hasta que exista una lista propia validada.

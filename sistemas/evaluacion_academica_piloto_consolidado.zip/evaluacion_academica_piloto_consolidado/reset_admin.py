import os
import sqlite3
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
raw_db_path = os.getenv("DATABASE_PATH", "data/evaluacion.db").strip() or "data/evaluacion.db"
db_path = raw_db_path if os.path.isabs(raw_db_path) else os.path.join(BASE_DIR, raw_db_path)
email = os.getenv("ADMIN_INITIAL_EMAIL", "admin@piloto.cl").strip().lower()
password = os.getenv("ADMIN_INITIAL_PASSWORD", "ClaveInicialSegura123")
nombre = os.getenv("ADMIN_INITIAL_NAME", "Administrador del piloto").strip()

if not password or len(password) < 8:
    raise SystemExit("ADMIN_INITIAL_PASSWORD debe existir y tener al menos 8 caracteres.")

os.makedirs(os.path.dirname(db_path), exist_ok=True)
conn = sqlite3.connect(db_path)
cur = conn.cursor()

# Asegura que las tablas existan, usando el bootstrap normal del sistema.
conn.close()
from database import bootstrap_database, get_connection
bootstrap_database()

with get_connection() as db:
    row = db.execute("SELECT id FROM usuarios WHERE email = ?", (email,)).fetchone()
    password_hash = generate_password_hash(password)
    if row:
        db.execute(
            """
            UPDATE usuarios
            SET nombre = ?, password_hash = ?, rol = 'admin', activo = 1
            WHERE email = ?
            """,
            (nombre, password_hash, email),
        )
        accion = "actualizado"
        user_id = row["id"]
    else:
        cur = db.execute(
            """
            INSERT INTO usuarios (email, nombre, password_hash, rol, activo, creado_en)
            VALUES (?, ?, ?, 'admin', 1, datetime('now'))
            """,
            (email, nombre, password_hash),
        )
        accion = "creado"
        user_id = cur.lastrowid
    db.execute(
        """
        INSERT INTO bitacora (usuario_id, accion, entidad, entidad_id, detalle, creado_en)
        VALUES (?, 'reset admin', 'usuarios', ?, ?, datetime('now'))
        """,
        (user_id, user_id, f"Admin {accion}: {email}"),
    )
    db.commit()

print(f"Admin {accion}: {email}")
print(f"Contraseña desde .env: {password}")
print(f"Base usada: {db_path}")

# Piloto de Evaluación Académica por Comisión

Aplicación Flask + SQLite para gestionar una persona académica con múltiples evaluaciones anuales independientes, importar declaraciones desde Excel y asociar evidencias a evaluación, área o actividad.

## Instalación y ejecución

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate

pip install -r requirements.txt
```

Copie `.env.example` como `.env` y defina al menos una clave secreta y las credenciales del administrador inicial:

```env
SECRET_KEY=una-clave-larga-y-aleatoria
DATABASE_PATH=data/evaluacion.db
ADMIN_INITIAL_EMAIL=admin@ejemplo.cl
ADMIN_INITIAL_PASSWORD=una-clave-segura
FLASK_ENV=development
```

Luego ejecute:

```bash
python app.py
```

Abra `http://127.0.0.1:5000`.

## Importación del ZIP de evidencias

### Desde la interfaz

1. Ingrese como administrador.
2. En **Importar convenio y evidencias**, seleccione el ZIP.
3. El sistema detecta los Excel anuales `2023`, `2024`, `2025`, etc.
4. Se crea una sola persona real y una evaluación independiente por año.
5. Revise el reporte de importación y las evidencias pendientes.
6. Abra cada evaluación anual para corregir actividades o asociar evidencias manualmente.

### Desde línea de comandos

La ruta web y el script usan exactamente el mismo módulo `importador.py`:

```bash
python importar_evidencias.py "C:\ruta\CONVENIO DESEMPEÑO.zip"
```

## Fuente de verdad y cálculo de horas

Los Excel anuales son la única fuente que define áreas activas, actividades, horas y observaciones. Los nombres de carpetas de evidencias **nunca** activan áreas ni asignan porcentajes.

Por actividad, se conservan por separado:
- 1er semestre comprometido: h/semana y h/semestre;
- 1er semestre realizado: h/semana y h/semestre;
- 2do semestre comprometido: h/semana y h/semestre;
- 2do semestre realizado: h/semana y h/semestre;
- observación, contexto, evidencia textual y fila de origen.

El Excel revisado trabaja con 36 semanas lectivas y 44 semanas para el promedio anual equivalente. La aplicación usa:

```text
horas anuales = (h/sem S1 + h/sem S2) × 18
                + h/semestre S1 + h/semestre S2

promedio semanal anual = horas anuales / 44

% área = horas anuales del área / horas anuales de todas las áreas activas × 100
```

Las celdas vacías se guardan como `NULL`; los ceros explícitos se mantienen como `0`. Esto evita inventar carga en el primer semestre de 2023.

## Modelo de datos

- `personas_academicas`: persona real (`A-001`).
- `academicos`: se mantiene por compatibilidad con el sistema original, pero cada fila representa ahora **una evaluación anual** (`A-001-2023`, `A-001-2024`, `A-001-2025`).
- `areas_compromiso`: resumen calculado de cada área para un año.
- `actividades_comprometidas`: detalle semestral importado o editado.
- `evidencias`: archivos asociados a persona/evaluación/área/actividad, con metadatos y estado de asociación.
- `asignaciones_evaluacion`, `evaluaciones_individuales`, `evaluacion_final_comision`: conservan el flujo original de evaluación y deliberación.
- `importaciones`: guarda un reporte JSON completo de cada importación.

## Asociación de evidencias

La asociación automática es deliberadamente conservadora:
- el año se toma primero del nombre de archivo/carpeta;
- una carpeta puede **sugerir** un área solo si esa área ya está activa según el Excel;
- una actividad se asigna automáticamente solo con una coincidencia suficientemente fuerte;
- si hay ambigüedad, la evidencia queda a nivel de área o como `pendiente` para revisión administrativa;
- se pueden subir múltiples archivos directamente desde cada actividad.

`Educación Continua - VIME` se mantiene con catálogo abierto. En los Excel revisados la validación de esa sección reutiliza por error la lista de Docencia; el sistema detecta esa anomalía y la reporta, pero no copia la lista.

## Migración y reimportación

`database.py` agrega de forma idempotente las columnas y tablas nuevas. No elimina la base existente. Si una evaluación anual ya contiene borradores/envíos o acuerdos de comisión, el importador no reemplaza sus áreas ni actividades. Las evidencias cargadas manualmente tampoco se eliminan en una reimportación.

## Evidencias y almacenamiento persistente

Por defecto las evidencias quedan en `data/uploads`. Si `DATABASE_PATH` apunta a un disco persistente externo (por ejemplo `/var/data/evaluacion.db` en Render), el sistema usa `/var/data/uploads` automáticamente, salvo que se defina `UPLOAD_ROOT`.

## Validación incluida

`data/import_reports/reporte_validacion_hosein_2023_2025.json` contiene el reporte producido al validar el importador con el ZIP entregado para el piloto.
